
import mongoose from 'mongoose';

/**
 * Server-Side Database Logic.
 * Run this on your Node.js/Express backend.
 */

// --- Connection Setup ---
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/nexus_crm');
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    (process as any).exit(1);
  }
};

// --- Schemas ---

// 1. User Schema (Authentication & Roles)
const userSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true }, // maintaining string ID for compatibility with frontend mocks
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  role: { 
    type: String, 
    enum: ['MD', 'MANAGER', 'EMPLOYEE'], 
    default: 'EMPLOYEE' 
  },
  department: { 
    type: String, 
    enum: ['EXECUTIVE', 'SALES', 'FINANCE', 'HR', 'SERVICES'],
    required: true 
  },
  avatar: String
}, { timestamps: true });

// 2. Lead Schema (Sales Department)
const leadSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  customerName: { type: String, required: true },
  company: { type: String, required: true },
  value: { type: Number, required: true },
  status: { 
    type: String, 
    enum: ['New', 'Contacted', 'Proposal', 'Won', 'Lost'], 
    default: 'New' 
  },
  assignedToId: { type: String, required: true },
  lastActivity: { type: String }, // Storing as string YYYY-MM-DD for simplicity
  nextFollowUp: { type: String }
}, { timestamps: true });

// 3. Invoice Schema (Finance Department)
const invoiceSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  clientName: { type: String, required: true },
  amount: { type: Number, required: true },
  date: { type: String },
  dueDate: { type: String },
  status: { 
    type: String, 
    enum: ['Paid', 'Pending', 'Overdue'], 
    default: 'Pending' 
  },
  departmentId: { type: String, required: true },
  lastReminderSent: { type: String }
}, { timestamps: true });

// 4. Employee Schema (HR Department)
const reviewSchema = new mongoose.Schema({
  id: String,
  date: String,
  rating: Number,
  notes: String,
  goals: String,
  reviewerId: String
});

const employeeSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  position: { type: String, required: true },
  department: { type: String, required: true },
  salary: { type: Number, required: true },
  joinDate: { type: String },
  performanceRating: { type: Number, min: 1, max: 5 },
  reviews: [reviewSchema],
  nextReviewDate: { type: String }
}, { timestamps: true });

// 5. Vehicle Schema (Inventory)
const vehicleSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  vin: { type: String, required: true, unique: true },
  model: { type: String, required: true },
  fuelType: { type: String, enum: ['Petrol', 'Diesel', 'Hybrid', 'Electric'], default: 'Petrol' },
  variant: { type: String, required: true },
  color: { type: String, required: true },
  price: { type: Number, required: true },
  status: { type: String, enum: ['Available', 'Booked', 'Sold'], default: 'Available' },
  image: String
}, { timestamps: true });

// 6. Service Job Schema
const serviceJobSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  customerName: { type: String, required: true },
  vehicleModel: { type: String, required: true },
  registrationNumber: { type: String, required: true },
  serviceType: { type: String, required: true },
  status: { type: String, enum: ['Pending', 'In Progress', 'Washing', 'Ready', 'Delivered'], default: 'Pending' },
  assignedMechanic: String,
  estimatedCost: Number,
  dateIn: String
}, { timestamps: true });

// 7. Test Drive Schema
const testDriveSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  customerName: { type: String, required: true },
  vehicleModel: { type: String, required: true },
  date: { type: String, required: true },
  timeSlot: { type: String, required: true },
  status: { type: String, enum: ['Scheduled', 'Completed', 'Cancelled'], default: 'Scheduled' },
  assignedSalesPersonId: String
}, { timestamps: true });

// 8. Quotation Schema
const quotationSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  customerName: String,
  vehicleId: String,
  exShowroomPrice: Number,
  insurance: Number,
  registrationCharges: Number,
  accessories: Number,
  totalOnRoadPrice: Number,
  date: String
}, { timestamps: true });

// 9. Loan Schema
const loanSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  customerName: String,
  vehicleModel: String,
  bankName: String,
  loanAmount: Number,
  status: { type: String, enum: ['Applied', 'Processing', 'Approved', 'Rejected', 'Disbursed'], default: 'Applied' },
  applicationDate: String
}, { timestamps: true });

// 10. Booking Schema
const bookingSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  customerName: String,
  phone: String,
  vehicleId: String,
  vehicleDetails: String,
  basePrice: Number,
  discount: Number,
  accessoriesList: String,
  accessoriesCost: Number,
  finalPrice: Number,
  bookingAmountPaid: Number,
  date: String
}, { timestamps: true });

// --- Models Export ---
// Check if model exists to prevent overwrite error in hot-reload environments
export const User = (mongoose.models.User || mongoose.model('User', userSchema)) as mongoose.Model<any>;
export const Lead = (mongoose.models.Lead || mongoose.model('Lead', leadSchema)) as mongoose.Model<any>;
export const Invoice = (mongoose.models.Invoice || mongoose.model('Invoice', invoiceSchema)) as mongoose.Model<any>;
export const Employee = (mongoose.models.Employee || mongoose.model('Employee', employeeSchema)) as mongoose.Model<any>;
export const Vehicle = (mongoose.models.Vehicle || mongoose.model('Vehicle', vehicleSchema)) as mongoose.Model<any>;
export const ServiceJob = (mongoose.models.ServiceJob || mongoose.model('ServiceJob', serviceJobSchema)) as mongoose.Model<any>;
export const TestDrive = (mongoose.models.TestDrive || mongoose.model('TestDrive', testDriveSchema)) as mongoose.Model<any>;
export const Quotation = (mongoose.models.Quotation || mongoose.model('Quotation', quotationSchema)) as mongoose.Model<any>;
export const Loan = (mongoose.models.Loan || mongoose.model('Loan', loanSchema)) as mongoose.Model<any>;
export const Booking = (mongoose.models.Booking || mongoose.model('Booking', bookingSchema)) as mongoose.Model<any>;

export default connectDB;
