
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import connectDB, { Lead, Invoice, Employee, User, Vehicle, ServiceJob, TestDrive, Quotation, Loan, Booking } from './mongo.ts';

// Load environment variables
dotenv.config();

// Initialize App
const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors() as any);
app.use(express.json({ limit: '10mb' })); // Increased limit for Base64 images

// Database Connection
connectDB();

// --- API ROUTES ---

// SEED ROUTE (Populate Database)
app.post('/api/seed', async (req, res) => {
  try {
    console.log('Seeding database...');
    
    // 1. Clear existing data
    await Promise.all([
      Lead.deleteMany({}),
      Invoice.deleteMany({}),
      Employee.deleteMany({}),
      User.deleteMany({}),
      Vehicle.deleteMany({}),
      ServiceJob.deleteMany({}),
      TestDrive.deleteMany({}),
      Quotation.deleteMany({}),
      Loan.deleteMany({}),
      Booking.deleteMany({})
    ]);

    // 2. Define Mock Data (Hardcoded here to ensure availability on backend)
    const getDate = (offsetDays: number) => {
        const d = new Date();
        d.setDate(d.getDate() + offsetDays);
        return d.toISOString().split('T')[0];
    };

    const users = [
        { id: 'u1', name: 'Alice Sterling', email: 'alice@nexus.com', role: 'MD', department: 'EXECUTIVE', avatar: 'https://picsum.photos/seed/alice/100/100' },
        { id: 'u2', name: 'Bob Salesman', email: 'bob@nexus.com', role: 'MANAGER', department: 'SALES', avatar: 'https://picsum.photos/seed/bob/100/100' },
        { id: 'u3', name: 'Charlie Closer', email: 'charlie@nexus.com', role: 'EMPLOYEE', department: 'SALES', avatar: 'https://picsum.photos/seed/charlie/100/100' },
        { id: 'u4', name: 'Diana Finance', email: 'diana@nexus.com', role: 'MANAGER', department: 'FINANCE', avatar: 'https://picsum.photos/seed/diana/100/100' },
        { id: 'u5', name: 'Evan HR', email: 'evan@nexus.com', role: 'MANAGER', department: 'HR', avatar: 'https://picsum.photos/seed/evan/100/100' },
        { id: 'u6', name: 'Fiona Tech', email: 'fiona@nexus.com', role: 'EMPLOYEE', department: 'SERVICES', avatar: 'https://picsum.photos/seed/fiona/100/100' }
    ];

    const leads = [
        { id: 'l1', customerName: 'Acme Corp', company: 'Fleet Upgrade (5 Innovas)', value: 12500000, status: 'Proposal', assignedToId: 'u2', lastActivity: getDate(-5), nextFollowUp: getDate(2) },
        { id: 'l2', customerName: 'Rahul Verma', company: 'Personal - Fortuner', value: 4800000, status: 'New', assignedToId: 'u3', lastActivity: getDate(-1), nextFollowUp: getDate(0) },
        { id: 'l3', customerName: 'Tech Giants', company: 'Corporate Transport', value: 8500000, status: 'Won', assignedToId: 'u2', lastActivity: getDate(-20) },
        { id: 'l4', customerName: 'Local Travels', company: 'Urban Cruiser Fleet', value: 3600000, status: 'Lost', assignedToId: 'u3', lastActivity: getDate(-10) },
        { id: 'l5', customerName: 'Dr. Anjali Gupta', company: 'Personal - Camry', value: 4500000, status: 'Contacted', assignedToId: 'u3', lastActivity: getDate(-2), nextFollowUp: getDate(5) },
    ];

    const invoices = [
        { id: 'inv1', clientName: 'Tech Giants', amount: 8500000, date: getDate(-30), dueDate: getDate(0), status: 'Paid', departmentId: 'SALES' },
        { id: 'inv2', clientName: 'Acme Corp', amount: 2500000, date: getDate(-5), dueDate: getDate(25), status: 'Pending', departmentId: 'SALES' },
        { id: 'inv3', clientName: 'Internal Audit', amount: 50000, date: getDate(-15), dueDate: getDate(15), status: 'Paid', departmentId: 'FINANCE' },
        { id: 'inv4', clientName: 'Local Travels', amount: 120000, date: getDate(-60), dueDate: getDate(-30), status: 'Overdue', departmentId: 'SALES' },
    ];

    const employees = [
        { 
            id: 'e1', name: 'Bob Salesman', position: 'Sales Manager', department: 'SALES', salary: 120000, joinDate: '2021-01-15', performanceRating: 4.5, nextReviewDate: getDate(10),
            reviews: [
                { id: 'r1', date: '2023-06-15', rating: 4, notes: 'Solid performance.', goals: 'Increase team size.', reviewerId: 'u1' },
                { id: 'r2', date: '2023-12-15', rating: 5, notes: 'Exceptional leadership.', goals: 'Mentor juniors.', reviewerId: 'u1' }
            ]
        },
        { id: 'e2', name: 'Charlie Closer', position: 'Sales Rep', department: 'SALES', salary: 45000, joinDate: '2022-03-10', performanceRating: 4.2, nextReviewDate: getDate(45), reviews: [] },
        { id: 'e3', name: 'Diana Finance', position: 'CFO', department: 'FINANCE', salary: 250000, joinDate: '2020-06-01', performanceRating: 4.9, nextReviewDate: getDate(90), reviews: [] }
    ];

    const vehicles = [
        { id: 'v1', vin: 'MBJ1123456', model: 'Fortuner', fuelType: 'Diesel', variant: 'Legender 4x4', color: 'Super White', price: 4800000, status: 'Available' },
        { id: 'v2', vin: 'MBJ1123457', model: 'Innova Hycross', fuelType: 'Hybrid', variant: 'ZX Hybrid', color: 'Blackish Ageha', price: 3200000, status: 'Booked' },
        { id: 'v3', vin: 'MBJ1123458', model: 'Urban Cruiser', fuelType: 'Petrol', variant: 'V AT', color: 'Rustic Brown', price: 1200000, status: 'Available' },
        { id: 'v4', vin: 'MBJ1123459', model: 'Camry', fuelType: 'Hybrid', variant: 'Hybrid', color: 'Platinum White', price: 4500000, status: 'Available' },
        { id: 'v5', vin: 'MBJ1123460', model: 'Hilux', fuelType: 'Diesel', variant: 'High 4x4', color: 'Emotional Red', price: 3700000, status: 'Sold' },
    ];

    const serviceJobs = [
        { id: 'j1', customerName: 'Rahul Sharma', vehicleModel: 'Innova Crysta', registrationNumber: 'DL-8C-9988', serviceType: 'General Service', status: 'In Progress', estimatedCost: 8500, dateIn: getDate(0) },
        { id: 'j2', customerName: 'Priya Singh', vehicleModel: 'Fortuner', registrationNumber: 'HR-26-DQ-1122', serviceType: 'Repair', status: 'Pending', estimatedCost: 15000, dateIn: getDate(-1) },
        { id: 'j3', customerName: 'Amit Patel', vehicleModel: 'Glanza', registrationNumber: 'UP-16-AB-1234', serviceType: 'Washing', status: 'Washing', estimatedCost: 500, dateIn: getDate(0) },
        { id: 'j4', customerName: 'Sneha Gupta', vehicleModel: 'Hyryder', registrationNumber: 'DL-1C-ZZ-5555', serviceType: 'Inspection', status: 'Ready', estimatedCost: 0, dateIn: getDate(-2) },
    ];

    // 3. Insert
    await User.insertMany(users);
    await Lead.insertMany(leads);
    await Invoice.insertMany(invoices);
    await Employee.insertMany(employees);
    await Vehicle.insertMany(vehicles);
    await ServiceJob.insertMany(serviceJobs);

    console.log('Database seeded successfully.');
    res.json({ message: 'Database populated with mock data.' });

  } catch (error) {
    console.error('Seed Error:', error);
    res.status(500).json({ message: 'Error seeding database', error });
  }
});

// 1. Sales Routes
const salesRouter = express.Router();

salesRouter.get('/leads', async (req, res) => {
  try {
    const leads = await Lead.find({});
    res.json(leads);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching leads' });
  }
});

salesRouter.post('/leads', async (req, res) => {
  try {
    const newLead = new Lead(req.body);
    const savedLead = await newLead.save();
    console.log(`> Created new lead: ${savedLead.customerName}`);
    res.status(201).json(savedLead);
  } catch (error) {
    res.status(400).json({ message: 'Error creating lead', error });
  }
});

salesRouter.patch('/leads/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updatedLead = await Lead.findOneAndUpdate({ id: id }, req.body, { new: true });
    console.log(`> Updated lead: ${id}`);
    res.json(updatedLead);
  } catch (error) {
    res.status(400).json({ message: 'Error updating lead' });
  }
});

// Inventory Routes
salesRouter.get('/inventory', async (req, res) => {
    try {
        const vehicles = await Vehicle.find({});
        res.json(vehicles);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching inventory' });
    }
});

salesRouter.post('/inventory', async (req, res) => {
  try {
      const newVehicle = new Vehicle(req.body);
      const saved = await newVehicle.save();
      console.log(`> Added Vehicle: ${saved.model}`);
      res.status(201).json(saved);
  } catch (e) { res.status(400).json(e); }
});

salesRouter.patch('/inventory/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const updated = await Vehicle.findOneAndUpdate({ id: id }, req.body, { new: true });
        console.log(`> Updated Vehicle: ${id}`);
        res.json(updated);
    } catch (e) { res.status(400).json(e); }
});

// Test Drive Routes
salesRouter.get('/test-drives', async (req, res) => {
    try {
        const drives = await TestDrive.find({});
        res.json(drives);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching test drives' });
    }
});
salesRouter.post('/test-drives', async (req, res) => {
    try {
        const newDrive = new TestDrive(req.body);
        const saved = await newDrive.save();
        res.json(saved);
    } catch (e) { res.status(400).send(); }
});
salesRouter.patch('/test-drives/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const updated = await TestDrive.findOneAndUpdate({ id: id }, req.body, { new: true });
        console.log(`> Updated Test Drive: ${id}`);
        res.json(updated);
    } catch (e) { res.status(400).send(); }
});

// Quotation Routes
salesRouter.post('/quotations', async (req, res) => {
    try {
        const quote = new Quotation(req.body);
        const saved = await quote.save();
        res.json(saved);
    } catch (e) { res.status(400).send(); }
});

// Booking Routes (NEW)
salesRouter.get('/bookings', async (req, res) => {
    try {
        const bookings = await Booking.find({});
        res.json(bookings);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching bookings' });
    }
});

salesRouter.post('/bookings', async (req, res) => {
    try {
        const booking = new Booking(req.body);
        const saved = await booking.save();
        
        // Auto-update vehicle status to 'Booked'
        if(saved.vehicleId) {
            await Vehicle.findOneAndUpdate({ id: saved.vehicleId }, { status: 'Booked' });
        }

        console.log(`> Created Booking for: ${saved.customerName}`);
        res.json(saved);
    } catch (e) { res.status(400).send(); }
});

// 2. Finance Routes
const financeRouter = express.Router();

financeRouter.get('/invoices', async (req, res) => {
  try {
    const invoices = await Invoice.find({});
    res.json(invoices);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching invoices' });
  }
});

financeRouter.post('/invoices', async (req, res) => {
  try {
    const newInvoice = new Invoice(req.body);
    const savedInvoice = await newInvoice.save();
    console.log(`> Created invoice for: ${savedInvoice.clientName}`);
    res.status(201).json(savedInvoice);
  } catch (error) {
    res.status(400).json({ message: 'Error creating invoice', error });
  }
});

financeRouter.patch('/invoices/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updatedInvoice = await Invoice.findOneAndUpdate({ id: id }, req.body, { new: true });
      console.log(`> Updated invoice: ${id}`);
      res.json(updatedInvoice);
    } catch (error) {
      res.status(400).json({ message: 'Error updating invoice' });
    }
  });

// Loan Routes
financeRouter.get('/loans', async (req, res) => {
    try {
        const loans = await Loan.find({});
        res.json(loans);
    } catch (e) { res.status(500).send(); }
});
financeRouter.post('/loans', async (req, res) => {
    try {
        const ln = new Loan(req.body);
        const saved = await ln.save();
        res.json(saved);
    } catch (e) { res.status(400).send(); }
});
financeRouter.patch('/loans/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const updated = await Loan.findOneAndUpdate({ id }, req.body, { new: true });
        res.json(updated);
    } catch (e) { res.status(400).send(); }
});

// 3. HR Routes
const hrRouter = express.Router();

hrRouter.get('/employees', async (req, res) => {
  try {
    const employees = await Employee.find({});
    res.json(employees);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching employees' });
  }
});

hrRouter.post('/employees', async (req, res) => {
  try {
    const newEmployee = new Employee({
        ...req.body,
        reviews: [] 
    });
    const savedEmployee = await newEmployee.save();
    console.log(`> Registered employee: ${savedEmployee.name}`);
    res.status(201).json(savedEmployee);
  } catch (error) {
    res.status(400).json({ message: 'Error creating employee', error });
  }
});

hrRouter.post('/employees/:id/reviews', async (req, res) => {
    try {
        const { id } = req.params;
        const review = req.body;
        
        const employee = await Employee.findOne({ id });
        if (!employee) return res.status(404).json({ message: 'Employee not found' });

        employee.reviews.push(review);

        const total = employee.reviews.reduce((acc: number, r: any) => acc + r.rating, 0);
        employee.performanceRating = total / employee.reviews.length;

        await employee.save();
        console.log(`> Added review for: ${employee.name}`);
        res.status(201).json(employee);
    } catch (error) {
        res.status(400).json({ message: 'Error adding review', error });
    }
});

// 4. Services Routes
const serviceRouter = express.Router();

serviceRouter.get('/jobs', async (req, res) => {
    try {
        const jobs = await ServiceJob.find({});
        res.json(jobs);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching jobs' });
    }
});

serviceRouter.patch('/jobs/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const updated = await ServiceJob.findOneAndUpdate({ id: id }, req.body, { new: true });
        console.log(`> Updated Job Card: ${id}`);
        res.json(updated);
    } catch (error) {
        res.status(500).json({ message: 'Error updating job' });
    }
});

// 5. Auth/User Routes
const userRouter = express.Router();
userRouter.get('/users', async (req, res) => {
    const users = await User.find({});
    res.json(users);
});

// Mount Routers
app.use('/api/sales', salesRouter);
app.use('/api/finance', financeRouter);
app.use('/api/hr', hrRouter);
app.use('/api/services', serviceRouter);
app.use('/api/users', userRouter);

app.get('/', (req, res) => {
  res.send('Nexus CRM API is running');
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
