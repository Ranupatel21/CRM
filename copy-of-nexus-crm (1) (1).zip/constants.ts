
import { Department, Role, User, Lead, Invoice, Employee, Ticket, Vehicle, ServiceJob } from './types';

// Mock Users
export const MOCK_USERS: User[] = [
  {
    id: 'u1',
    name: 'Alice Sterling',
    email: 'alice@nexus.com',
    role: Role.MD,
    department: Department.EXECUTIVE,
    avatar: 'https://picsum.photos/seed/alice/100/100'
  },
  {
    id: 'u2',
    name: 'Bob Salesman',
    email: 'bob@nexus.com',
    role: Role.MANAGER,
    department: Department.SALES,
    avatar: 'https://picsum.photos/seed/bob/100/100'
  },
  {
    id: 'u3',
    name: 'Charlie Closer',
    email: 'charlie@nexus.com',
    role: Role.EMPLOYEE,
    department: Department.SALES,
    avatar: 'https://picsum.photos/seed/charlie/100/100'
  },
  {
    id: 'u4',
    name: 'Diana Finance',
    email: 'diana@nexus.com',
    role: Role.MANAGER,
    department: Department.FINANCE,
    avatar: 'https://picsum.photos/seed/diana/100/100'
  },
  {
    id: 'u5',
    name: 'Evan HR',
    email: 'evan@nexus.com',
    role: Role.MANAGER,
    department: Department.HR,
    avatar: 'https://picsum.photos/seed/evan/100/100'
  },
  {
    id: 'u6',
    name: 'Fiona Tech',
    email: 'fiona@nexus.com',
    role: Role.EMPLOYEE,
    department: Department.SERVICES,
    avatar: 'https://picsum.photos/seed/fiona/100/100'
  }
];

// Helper to get relative dates for robust mocking
const getDate = (offsetDays: number) => {
    const d = new Date();
    d.setDate(d.getDate() + offsetDays);
    return d.toISOString().split('T')[0];
};

// Mock Leads (Values in INR)
export const MOCK_LEADS: Lead[] = [
  { id: 'l1', customerName: 'Acme Corp', company: 'Fleet Upgrade (5 Innovas)', value: 12500000, status: 'Proposal', assignedToId: 'u2', lastActivity: getDate(-5), nextFollowUp: getDate(2) },
  { id: 'l2', customerName: 'Rahul Verma', company: 'Personal - Fortuner', value: 4800000, status: 'New', assignedToId: 'u3', lastActivity: getDate(-1), nextFollowUp: getDate(0) },
  { id: 'l3', customerName: 'Tech Giants', company: 'Corporate Transport', value: 8500000, status: 'Won', assignedToId: 'u2', lastActivity: getDate(-20) },
  { id: 'l4', customerName: 'Local Travels', company: 'Urban Cruiser Fleet', value: 3600000, status: 'Lost', assignedToId: 'u3', lastActivity: getDate(-10) },
  { id: 'l5', customerName: 'Dr. Anjali Gupta', company: 'Personal - Camry', value: 4500000, status: 'Contacted', assignedToId: 'u3', lastActivity: getDate(-2), nextFollowUp: getDate(5) },
];

// Mock Invoices (Values in INR)
export const MOCK_INVOICES: Invoice[] = [
  { id: 'inv1', clientName: 'Tech Giants', amount: 8500000, date: getDate(-30), dueDate: getDate(0), status: 'Paid', departmentId: Department.SALES },
  { id: 'inv2', clientName: 'Acme Corp', amount: 2500000, date: getDate(-5), dueDate: getDate(25), status: 'Pending', departmentId: Department.SALES },
  { id: 'inv3', clientName: 'Internal Audit', amount: 50000, date: getDate(-15), dueDate: getDate(15), status: 'Paid', departmentId: Department.FINANCE },
  { id: 'inv4', clientName: 'Local Travels', amount: 120000, date: getDate(-60), dueDate: getDate(-30), status: 'Overdue', departmentId: Department.SALES },
];

// Mock Employees (Salaries in INR Monthly)
export const MOCK_EMPLOYEES: Employee[] = [
  { 
    id: 'e1', 
    name: 'Bob Salesman', 
    position: 'Sales Manager', 
    department: Department.SALES, 
    salary: 120000, 
    joinDate: '2021-01-15', 
    performanceRating: 4.5,
    nextReviewDate: getDate(10),
    reviews: [
      { id: 'r1', date: '2023-06-15', rating: 4, notes: 'Solid performance, hit all quotas.', goals: 'Increase team size by 2.', reviewerId: 'u1' },
      { id: 'r2', date: '2023-12-15', rating: 5, notes: 'Exceptional leadership during Q4.', goals: 'Mentor junior reps.', reviewerId: 'u1' }
    ]
  },
  { 
    id: 'e2', 
    name: 'Charlie Closer', 
    position: 'Sales Rep', 
    department: Department.SALES, 
    salary: 45000, 
    joinDate: '2022-03-10', 
    performanceRating: 4.2,
    nextReviewDate: getDate(45),
    reviews: [
      { id: 'r3', date: '2023-03-10', rating: 4, notes: 'Good start, learning fast.', goals: 'Close 5 deals per month.', reviewerId: 'u2' }
    ]
  },
  { 
    id: 'e3', 
    name: 'Diana Finance', 
    position: 'CFO', 
    department: Department.FINANCE, 
    salary: 250000, 
    joinDate: '2020-06-01', 
    performanceRating: 4.9,
    nextReviewDate: getDate(90),
    reviews: []
  },
  { 
    id: 'e4', 
    name: 'Fiona Tech', 
    position: 'Service Head', 
    department: Department.SERVICES, 
    salary: 85000, 
    joinDate: '2021-11-20', 
    performanceRating: 3.8,
    reviews: []
  },
];

export const MOCK_TICKETS: Ticket[] = [
  { id: 't1', subject: 'Server Down', customerName: 'Acme Corp', priority: 'Critical', status: 'In Progress', assignedToId: 'u6' },
  { id: 't2', subject: 'Login Issue', customerName: 'Rahul Verma', priority: 'Medium', status: 'Resolved', assignedToId: 'u6' },
  { id: 't3', subject: 'Feature Request', customerName: 'Tech Giants', priority: 'Low', status: 'Open', assignedToId: 'u6' },
];

// --- NEW MOCK DATA ---

export const MOCK_VEHICLES: Vehicle[] = [
    { id: 'v1', vin: 'MBJ1123456', model: 'Fortuner', fuelType: 'Diesel', variant: 'Legender 4x4', color: 'Super White', price: 4800000, status: 'Available' },
    { id: 'v2', vin: 'MBJ1123457', model: 'Innova Hycross', fuelType: 'Hybrid', variant: 'ZX Hybrid', color: 'Blackish Ageha', price: 3200000, status: 'Booked' },
    { id: 'v3', vin: 'MBJ1123458', model: 'Urban Cruiser', fuelType: 'Petrol', variant: 'V AT', color: 'Rustic Brown', price: 1200000, status: 'Available' },
    { id: 'v4', vin: 'MBJ1123459', model: 'Camry', fuelType: 'Hybrid', variant: 'Hybrid', color: 'Platinum White', price: 4500000, status: 'Available' },
    { id: 'v5', vin: 'MBJ1123460', model: 'Hilux', fuelType: 'Diesel', variant: 'High 4x4', color: 'Emotional Red', price: 3700000, status: 'Sold' },
];

export const MOCK_SERVICE_JOBS: ServiceJob[] = [
    { id: 'j1', customerName: 'Rahul Sharma', vehicleModel: 'Innova Crysta', registrationNumber: 'DL-8C-9988', serviceType: 'General Service', status: 'In Progress', estimatedCost: 8500, dateIn: getDate(0) },
    { id: 'j2', customerName: 'Priya Singh', vehicleModel: 'Fortuner', registrationNumber: 'HR-26-DQ-1122', serviceType: 'Repair', status: 'Pending', estimatedCost: 15000, dateIn: getDate(-1) },
    { id: 'j3', customerName: 'Amit Patel', vehicleModel: 'Glanza', registrationNumber: 'UP-16-AB-1234', serviceType: 'Washing', status: 'Washing', estimatedCost: 500, dateIn: getDate(0) },
    { id: 'j4', customerName: 'Sneha Gupta', vehicleModel: 'Hyryder', registrationNumber: 'DL-1C-ZZ-5555', serviceType: 'Inspection', status: 'Ready', estimatedCost: 0, dateIn: getDate(-2) },
];
