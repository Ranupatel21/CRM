
import React, { useState } from 'react';
import { User, Lead, Invoice, Employee } from '../types';
import { Database, User as UserIcon, DollarSign, FileText, Briefcase, RefreshCw } from 'lucide-react';
import { api } from '../services/api';

interface AdminDataProps {
  data: {
    users: User[];
    leads: Lead[];
    invoices: Invoice[];
    employees: Employee[];
  }
}

type Tab = 'users' | 'leads' | 'invoices' | 'employees';

export const AdminData: React.FC<AdminDataProps> = ({ data }) => {
  const [activeTab, setActiveTab] = useState<Tab>('leads');
  const [seeding, setSeeding] = useState(false);

  const tabs = [
    { id: 'leads', label: 'Sales Leads', icon: DollarSign, count: data.leads.length },
    { id: 'invoices', label: 'Invoices', icon: FileText, count: data.invoices.length },
    { id: 'employees', label: 'Employees', icon: Briefcase, count: data.employees.length },
    { id: 'users', label: 'System Users', icon: UserIcon, count: data.users.length },
  ];

  const handleSeed = async () => {
    if (!confirm('Are you sure? This will delete all existing database data and replace it with mock data.')) return;
    
    setSeeding(true);
    try {
        await api.system.seedDatabase();
        window.location.reload(); // Refresh to see data
    } catch (e) {
        alert('Error seeding database');
    } finally {
        setSeeding(false);
    }
  };

  const renderTable = () => {
    switch(activeTab) {
      case 'users':
        return (
          <table className="w-full text-left text-sm text-slate-600">
             <thead className="bg-slate-100 uppercase text-xs font-semibold text-slate-500">
                <tr>
                    <th className="px-6 py-3">ID</th>
                    <th className="px-6 py-3">Name</th>
                    <th className="px-6 py-3">Email</th>
                    <th className="px-6 py-3">Role</th>
                    <th className="px-6 py-3">Department</th>
                </tr>
             </thead>
             <tbody className="divide-y divide-slate-100">
                {data.users.map(u => (
                    <tr key={u.id} className="hover:bg-slate-50">
                        <td className="px-6 py-3 font-mono text-xs">{u.id}</td>
                        <td className="px-6 py-3">{u.name}</td>
                        <td className="px-6 py-3">{u.email}</td>
                        <td className="px-6 py-3"><span className="bg-slate-200 px-2 py-0.5 rounded text-xs">{u.role}</span></td>
                        <td className="px-6 py-3">{u.department}</td>
                    </tr>
                ))}
             </tbody>
          </table>
        );
      case 'leads':
        return (
            <table className="w-full text-left text-sm text-slate-600">
               <thead className="bg-slate-100 uppercase text-xs font-semibold text-slate-500">
                  <tr>
                      <th className="px-6 py-3">ID</th>
                      <th className="px-6 py-3">Customer</th>
                      <th className="px-6 py-3">Company</th>
                      <th className="px-6 py-3">Value</th>
                      <th className="px-6 py-3">Status</th>
                      <th className="px-6 py-3">Assigned To</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                  {data.leads.map(l => (
                      <tr key={l.id} className="hover:bg-slate-50">
                          <td className="px-6 py-3 font-mono text-xs">{l.id}</td>
                          <td className="px-6 py-3 font-medium">{l.customerName}</td>
                          <td className="px-6 py-3">{l.company}</td>
                          <td className="px-6 py-3">₹{l.value.toLocaleString()}</td>
                          <td className="px-6 py-3">
                            <span className={`px-2 py-0.5 rounded text-xs text-white
                                ${l.status === 'Won' ? 'bg-green-500' : l.status === 'Lost' ? 'bg-red-500' : 'bg-blue-500'}`}>
                                {l.status}
                            </span>
                          </td>
                          <td className="px-6 py-3 text-xs">{l.assignedToId}</td>
                      </tr>
                  ))}
               </tbody>
            </table>
          );
       case 'invoices':
        return (
            <table className="w-full text-left text-sm text-slate-600">
               <thead className="bg-slate-100 uppercase text-xs font-semibold text-slate-500">
                  <tr>
                      <th className="px-6 py-3">ID</th>
                      <th className="px-6 py-3">Client</th>
                      <th className="px-6 py-3">Amount</th>
                      <th className="px-6 py-3">Issue Date</th>
                      <th className="px-6 py-3">Due Date</th>
                      <th className="px-6 py-3">Status</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                  {data.invoices.map(i => (
                      <tr key={i.id} className="hover:bg-slate-50">
                          <td className="px-6 py-3 font-mono text-xs">{i.id}</td>
                          <td className="px-6 py-3 font-medium">{i.clientName}</td>
                          <td className="px-6 py-3">₹{i.amount.toLocaleString()}</td>
                          <td className="px-6 py-3">{i.date}</td>
                          <td className="px-6 py-3">{i.dueDate || '-'}</td>
                          <td className="px-6 py-3">
                            <span className={`px-2 py-0.5 rounded text-xs
                                ${i.status === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                                {i.status}
                            </span>
                          </td>
                      </tr>
                  ))}
               </tbody>
            </table>
        );
       case 'employees':
        return (
            <table className="w-full text-left text-sm text-slate-600">
               <thead className="bg-slate-100 uppercase text-xs font-semibold text-slate-500">
                  <tr>
                      <th className="px-6 py-3">ID</th>
                      <th className="px-6 py-3">Name</th>
                      <th className="px-6 py-3">Position</th>
                      <th className="px-6 py-3">Department</th>
                      <th className="px-6 py-3">Salary</th>
                      <th className="px-6 py-3">Rating</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                  {data.employees.map(e => (
                      <tr key={e.id} className="hover:bg-slate-50">
                          <td className="px-6 py-3 font-mono text-xs">{e.id}</td>
                          <td className="px-6 py-3 font-medium">{e.name}</td>
                          <td className="px-6 py-3">{e.position}</td>
                          <td className="px-6 py-3">{e.department}</td>
                          <td className="px-6 py-3">₹{e.salary.toLocaleString()}</td>
                          <td className="px-6 py-3 font-bold">{e.performanceRating}</td>
                      </tr>
                  ))}
               </tbody>
            </table>
        );
    }
  };

  return (
    <div className="p-8 space-y-6 ml-64 bg-slate-50 min-h-screen">
       <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
                <div className="bg-slate-800 p-2 rounded-lg text-white">
                    <Database size={24} />
                </div>
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Master Database View</h1>
                    <p className="text-slate-500">Raw data tables for all system collections. Access restricted to Managing Directors.</p>
                </div>
            </div>
            <button 
                onClick={handleSeed}
                disabled={seeding}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors disabled:opacity-50"
            >
                <RefreshCw size={18} className={seeding ? "animate-spin" : ""} />
                {seeding ? "Populating..." : "Populate with Mock Data"}
            </button>
       </div>

       <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden min-h-[600px] flex flex-col">
            {/* Tabs */}
            <div className="flex border-b border-slate-200">
                {tabs.map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as Tab)}
                        className={`flex-1 py-4 text-sm font-medium flex items-center justify-center gap-2 border-b-2 transition-colors ${
                            activeTab === tab.id 
                            ? 'border-indigo-600 text-indigo-600 bg-indigo-50' 
                            : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                        }`}
                    >
                        <tab.icon size={18} />
                        {tab.label}
                        <span className="bg-slate-200 text-slate-600 text-[10px] px-1.5 py-0.5 rounded-full">{tab.count}</span>
                    </button>
                ))}
            </div>

            {/* Table Area */}
            <div className="flex-1 overflow-x-auto">
                {renderTable()}
            </div>
       </div>
    </div>
  );
};
