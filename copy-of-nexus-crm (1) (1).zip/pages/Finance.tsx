
import React, { useState, useEffect } from 'react';
import { Invoice, Department, LoanApplication } from '../types';
import { AIModal } from '../components/AIModal';
import { Plus, X, Mail, Landmark, TrendingUp } from 'lucide-react';
import { api } from '../services/api';

interface FinanceProps {
  invoices: Invoice[];
  refreshData: () => void;
}

export const Finance: React.FC<FinanceProps> = ({ invoices, refreshData }) => {
  const [activeTab, setActiveTab] = useState<'invoices' | 'loans' | 'commissions'>('invoices');
  const [loans, setLoans] = useState<LoanApplication[]>([]);
  const [showLoanModal, setShowLoanModal] = useState(false);
  const [newLoan, setNewLoan] = useState({ customerName: '', vehicleModel: '', bankName: '', loanAmount: 0 });

  useEffect(() => {
      if(activeTab === 'loans') api.finance.getLoans().then(setLoans);
  }, [activeTab]);

  const handleCreateLoan = async (e: React.FormEvent) => {
      e.preventDefault();
      const loan = await api.finance.createLoan({
          ...newLoan, status: 'Applied', applicationDate: new Date().toISOString().split('T')[0]
      });
      setLoans([...loans, loan]);
      setShowLoanModal(false);
  };

  const handleUpdateLoan = async (id: string, status: any) => {
      await api.finance.updateLoanStatus(id, status);
      setLoans(loans.map(l => l.id === id ? {...l, status} : l));
  }

  const renderLoans = () => (
      <div className="space-y-4">
          <div className="flex justify-end">
              <button onClick={() => setShowLoanModal(true)} className="bg-blue-600 text-white px-4 py-2 rounded font-bold flex items-center gap-2"><Plus size={18}/> New Application</button>
          </div>
          <div className="grid grid-cols-5 gap-4">
             {['Applied', 'Processing', 'Approved', 'Rejected', 'Disbursed'].map(status => (
                 <div key={status} className="bg-slate-100 p-2 rounded h-full">
                     <h4 className="font-bold text-slate-500 text-xs uppercase mb-2 text-center">{status}</h4>
                     <div className="space-y-2">
                         {loans.filter(l => l.status === status).map(l => (
                             <div key={l.id} className="bg-white p-3 rounded shadow text-sm border-l-4 border-blue-500">
                                 <p className="font-bold">{l.customerName}</p>
                                 <p className="text-xs">{l.bankName} - ₹{l.loanAmount.toLocaleString()}</p>
                                 <p className="text-xs text-slate-400">{l.vehicleModel}</p>
                                 <div className="mt-2 flex gap-1">
                                     {status === 'Applied' && <button onClick={() => handleUpdateLoan(l.id, 'Processing')} className="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded">Process</button>}
                                     {status === 'Processing' && <button onClick={() => handleUpdateLoan(l.id, 'Approved')} className="text-xs bg-green-100 text-green-600 px-2 py-1 rounded">Approve</button>}
                                     {status === 'Approved' && <button onClick={() => handleUpdateLoan(l.id, 'Disbursed')} className="text-xs bg-purple-100 text-purple-600 px-2 py-1 rounded">Disburse</button>}
                                 </div>
                             </div>
                         ))}
                     </div>
                 </div>
             ))}
          </div>

          {showLoanModal && (
              <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
                  <div className="bg-white p-6 rounded-lg w-full max-w-md">
                      <h3 className="font-bold mb-4">New Loan Application</h3>
                      <form onSubmit={handleCreateLoan} className="space-y-4">
                          <input required placeholder="Customer Name" className="w-full border p-2 rounded" value={newLoan.customerName} onChange={e => setNewLoan({...newLoan, customerName: e.target.value})} />
                          <input required placeholder="Vehicle Model" className="w-full border p-2 rounded" value={newLoan.vehicleModel} onChange={e => setNewLoan({...newLoan, vehicleModel: e.target.value})} />
                          <select className="w-full border p-2 rounded" value={newLoan.bankName} onChange={e => setNewLoan({...newLoan, bankName: e.target.value})}>
                              <option value="">Select Bank</option><option>HDFC Bank</option><option>SBI</option><option>ICICI Bank</option>
                          </select>
                          <input required type="number" placeholder="Amount (INR)" className="w-full border p-2 rounded" value={newLoan.loanAmount} onChange={e => setNewLoan({...newLoan, loanAmount: parseInt(e.target.value)})} />
                          <button className="w-full bg-blue-600 text-white py-2 rounded">Submit</button>
                          <button type="button" onClick={() => setShowLoanModal(false)} className="w-full text-slate-500 mt-2">Cancel</button>
                      </form>
                  </div>
              </div>
          )}
      </div>
  );

  const renderCommissions = () => (
      <div className="bg-white rounded-xl shadow p-6">
          <h3 className="font-bold mb-4 flex items-center gap-2"><TrendingUp/> Sales Commissions (Estimated)</h3>
          <p className="text-sm text-slate-500 mb-6">Calculated at 1% of value for 'Paid' invoices linked to Sales Dept.</p>
          <table className="w-full text-left">
              <thead>
                  <tr className="border-b bg-slate-50"><th className="p-3">Client</th><th className="p-3">Invoice Amount</th><th className="p-3">Status</th><th className="p-3 font-bold text-green-600">Commission (1%)</th></tr>
              </thead>
              <tbody>
                  {invoices.filter(i => i.departmentId === Department.SALES).map(inv => (
                      <tr key={inv.id} className="border-b">
                          <td className="p-3">{inv.clientName}</td>
                          <td className="p-3">₹{inv.amount.toLocaleString()}</td>
                          <td className="p-3"><span className={`px-2 py-1 rounded text-xs ${inv.status === 'Paid' ? 'bg-green-100' : 'bg-amber-100'}`}>{inv.status}</span></td>
                          <td className="p-3 font-bold">₹{(inv.amount * 0.01).toLocaleString()}</td>
                      </tr>
                  ))}
              </tbody>
          </table>
      </div>
  );

  return (
    <div className="p-8 space-y-6 ml-64 bg-slate-50 min-h-screen">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-slate-900">Finance & Banking</h1>
        <div className="flex gap-2 bg-white rounded-lg p-1 border shadow-sm">
            {['invoices', 'loans', 'commissions'].map(tab => (
                <button 
                    key={tab}
                    onClick={() => setActiveTab(tab as any)} 
                    className={`px-4 py-2 text-sm font-medium rounded capitalize ${activeTab === tab ? 'bg-slate-900 text-white' : 'text-slate-500 hover:text-slate-900'}`}
                >
                    {tab}
                </button>
            ))}
        </div>
      </div>

      {activeTab === 'invoices' && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
            <div className="p-6 border-b border-slate-100"><h3 className="font-bold text-lg text-slate-800">All Invoices</h3></div>
            <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-100">
                    <tr><th className="px-6 py-4">Client</th><th className="px-6 py-4">Amount</th><th className="px-6 py-4">Status</th><th className="px-6 py-4">Due Date</th></tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {invoices.map(inv => (
                        <tr key={inv.id} className="hover:bg-slate-50">
                            <td className="px-6 py-4 font-medium text-slate-900">{inv.clientName}</td>
                            <td className="px-6 py-4 font-semibold">₹{inv.amount.toLocaleString()}</td>
                            <td className="px-6 py-4"><span className={`px-2 py-1 rounded text-xs font-bold ${inv.status === 'Paid' ? 'bg-emerald-100 text-emerald-700' : inv.status === 'Overdue' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}`}>{inv.status}</span></td>
                            <td className="px-6 py-4 text-slate-500">{inv.dueDate}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
          </div>
      )}

      {activeTab === 'loans' && renderLoans()}
      {activeTab === 'commissions' && renderCommissions()}
    </div>
  );
};
