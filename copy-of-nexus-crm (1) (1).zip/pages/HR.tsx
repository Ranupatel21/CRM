
import React, { useState } from 'react';
import { Employee, Department, PerformanceReview } from '../types';
import { AIModal } from '../components/AIModal';
import { Star, UserPlus, X, ClipboardList, Clock, Target } from 'lucide-react';
import { api } from '../services/api';

interface HRProps {
  employees: Employee[];
  refreshData: () => void;
}

export const HR: React.FC<HRProps> = ({ employees, refreshData }) => {
  // Add Employee Modal State
  const [showAddModal, setShowAddModal] = useState(false);
  const [newEmployee, setNewEmployee] = useState({
    name: '',
    position: '',
    department: Department.SALES,
    salary: 0,
    joinDate: new Date().toISOString().split('T')[0],
    performanceRating: 3,
    reviews: [] as PerformanceReview[]
  });

  // Performance Review Modal State
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [reviewForm, setReviewForm] = useState({
      rating: 5,
      notes: '',
      goals: ''
  });

  const handleCreateEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    await api.hr.createEmployee(newEmployee);
    setShowAddModal(false);
    setNewEmployee({
        name: '',
        position: '',
        department: Department.SALES,
        salary: 0,
        joinDate: new Date().toISOString().split('T')[0],
        performanceRating: 3,
        reviews: []
    });
    refreshData();
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!selectedEmployee) return;

      await api.hr.addPerformanceReview(selectedEmployee.id, {
          date: new Date().toISOString().split('T')[0],
          rating: reviewForm.rating,
          notes: reviewForm.notes,
          goals: reviewForm.goals,
          reviewerId: 'current-user' // In real app, pass actual ID
      });

      setReviewForm({ rating: 5, notes: '', goals: '' });
      setSelectedEmployee(null);
      refreshData();
  }

  return (
    <div className="p-8 space-y-6 ml-64 bg-slate-50 min-h-screen">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-slate-900">Employee Directory</h1>
        <div className="flex gap-2">
            <AIModal contextData={employees} buttonLabel="HR Insights" />
            <button 
                onClick={() => setShowAddModal(true)}
                className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700 shadow-sm"
            >
                <UserPlus size={18} /> Register Employee
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {employees.map((emp) => (
            <div key={emp.id} className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-all flex flex-col">
                <div className="flex justify-between items-start mb-4">
                    <div>
                        <h3 className="text-xl font-bold text-slate-900">{emp.name}</h3>
                        <p className="text-indigo-600 text-sm font-medium">{emp.position}</p>
                    </div>
                    <div className="bg-slate-100 px-2 py-1 rounded text-xs font-semibold text-slate-600">
                        {emp.department}
                    </div>
                </div>
                
                <div className="space-y-2 text-sm text-slate-600 mb-4 flex-1">
                    <p className="flex justify-between"><span>Joined:</span> <span className="text-slate-900">{emp.joinDate}</span></p>
                    <p className="flex justify-between"><span>Salary:</span> <span className="text-slate-900">₹{emp.salary.toLocaleString()}</span></p>
                </div>

                <div className="border-t border-slate-100 pt-4 flex items-center justify-between mb-4">
                    <span className="text-xs text-slate-400 font-medium">AVG RATING</span>
                    <div className="flex items-center gap-1 text-amber-400">
                        <span className="text-slate-700 font-bold text-sm mr-1">{emp.performanceRating.toFixed(1)}</span>
                        <Star size={14} fill="currentColor" />
                    </div>
                </div>

                <button 
                    onClick={() => setSelectedEmployee(emp)}
                    className="w-full py-2 border border-indigo-100 text-indigo-600 rounded-lg text-sm font-semibold hover:bg-indigo-50 transition-colors flex items-center justify-center gap-2"
                >
                    <ClipboardList size={16} /> Manage Performance
                </button>
            </div>
        ))}
      </div>

      {/* Add Employee Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
                <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                    <h3 className="text-lg font-bold">Register New Employee</h3>
                    <button onClick={() => setShowAddModal(false)}><X size={20} className="text-slate-400" /></button>
                </div>
                <form onSubmit={handleCreateEmployee} className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                        <input 
                            required 
                            type="text" 
                            className="w-full border border-slate-300 rounded-lg px-3 py-2"
                            value={newEmployee.name}
                            onChange={(e) => setNewEmployee({...newEmployee, name: e.target.value})}
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Position</label>
                        <input 
                            required 
                            type="text" 
                            className="w-full border border-slate-300 rounded-lg px-3 py-2"
                            value={newEmployee.position}
                            onChange={(e) => setNewEmployee({...newEmployee, position: e.target.value})}
                        />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Department</label>
                            <select 
                                className="w-full border border-slate-300 rounded-lg px-3 py-2"
                                value={newEmployee.department}
                                onChange={(e) => setNewEmployee({...newEmployee, department: e.target.value as Department})}
                            >
                                {Object.values(Department).map(d => (
                                    <option key={d} value={d}>{d}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Salary (₹)</label>
                            <input 
                                required 
                                type="number" 
                                className="w-full border border-slate-300 rounded-lg px-3 py-2"
                                value={newEmployee.salary}
                                onChange={(e) => setNewEmployee({...newEmployee, salary: parseInt(e.target.value) || 0})}
                            />
                        </div>
                    </div>
                    <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-lg font-medium hover:bg-indigo-700">
                        Register Employee
                    </button>
                </form>
            </div>
        </div>
      )}

      {/* Performance Review Modal */}
      {selectedEmployee && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
                {/* Header */}
                <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                    <div>
                        <h3 className="text-xl font-bold text-slate-800">Performance Management</h3>
                        <p className="text-slate-500 text-sm">Reviewing: <span className="font-semibold text-indigo-600">{selectedEmployee.name}</span></p>
                    </div>
                    <button onClick={() => setSelectedEmployee(null)}><X size={24} className="text-slate-400 hover:text-slate-600" /></button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 flex flex-col md:flex-row gap-8">
                    {/* Left: Timeline */}
                    <div className="flex-1">
                        <h4 className="font-bold text-slate-700 mb-4 flex items-center gap-2">
                            <Clock size={18} className="text-indigo-500" /> Review History
                        </h4>
                        
                        <div className="space-y-6 relative before:absolute before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                            {selectedEmployee.reviews && selectedEmployee.reviews.length > 0 ? (
                                selectedEmployee.reviews.map((review) => (
                                    <div key={review.id} className="relative pl-10">
                                        <div className="absolute left-2 top-1.5 w-4 h-4 rounded-full bg-indigo-600 border-4 border-white shadow-sm"></div>
                                        <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                                            <div className="flex justify-between items-start mb-2">
                                                <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">{review.date}</span>
                                                <div className="flex items-center gap-1">
                                                    <span className="font-bold text-slate-700">{review.rating}/5</span>
                                                    <Star size={14} className="fill-amber-400 text-amber-400" />
                                                </div>
                                            </div>
                                            <p className="text-sm text-slate-700 mb-3">{review.notes}</p>
                                            {review.goals && (
                                                <div className="text-xs bg-emerald-50 text-emerald-700 p-2 rounded border border-emerald-100 flex gap-2 items-start">
                                                    <Target size={14} className="mt-0.5 shrink-0" />
                                                    <span><strong>Goals Set:</strong> {review.goals}</span>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                ))
                            ) : (
                                <div className="pl-10 text-slate-400 italic text-sm">No reviews recorded yet.</div>
                            )}
                        </div>
                    </div>

                    {/* Right: Add Review Form */}
                    <div className="w-full md:w-1/3 bg-white">
                        <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 sticky top-0">
                            <h4 className="font-bold text-slate-800 mb-4">Add New Review</h4>
                            <form onSubmit={handleSubmitReview} className="space-y-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Rating (1-5)</label>
                                    <div className="flex gap-2">
                                        {[1, 2, 3, 4, 5].map((star) => (
                                            <button
                                                key={star}
                                                type="button"
                                                onClick={() => setReviewForm({ ...reviewForm, rating: star })}
                                                className={`p-2 rounded-lg transition-colors ${
                                                    reviewForm.rating >= star ? 'text-amber-400 bg-amber-50' : 'text-slate-300 bg-slate-100'
                                                }`}
                                            >
                                                <Star size={20} fill="currentColor" />
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Performance Notes</label>
                                    <textarea
                                        required
                                        className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm h-24 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                                        placeholder="Describe strengths and weaknesses..."
                                        value={reviewForm.notes}
                                        onChange={(e) => setReviewForm({...reviewForm, notes: e.target.value})}
                                    ></textarea>
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Goals for Next Period</label>
                                    <textarea
                                        className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm h-20 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                                        placeholder="Set actionable targets..."
                                        value={reviewForm.goals}
                                        onChange={(e) => setReviewForm({...reviewForm, goals: e.target.value})}
                                    ></textarea>
                                </div>

                                <button type="submit" className="w-full bg-indigo-600 text-white py-2.5 rounded-lg font-semibold hover:bg-indigo-700 transition-colors shadow-sm">
                                    Submit Review
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
          </div>
      )}
    </div>
  );
};
