
import React, { useState, useEffect } from 'react';
import { ServiceJob } from '../types';
import { api } from '../services/api';
import { Wrench, Clock, CheckCircle, Search, Droplets, History, ArrowLeft } from 'lucide-react';

const getStatusColor = (status: string) => {
    switch(status) {
        case 'Pending': return 'bg-slate-100 text-slate-600 border-slate-200';
        case 'In Progress': return 'bg-blue-50 text-blue-600 border-blue-200';
        case 'Washing': return 'bg-cyan-50 text-cyan-600 border-cyan-200';
        case 'Ready': return 'bg-emerald-50 text-emerald-600 border-emerald-200';
        case 'Delivered': return 'bg-slate-200 text-slate-500 border-slate-300 opacity-75';
        default: return 'bg-white';
    }
};

interface JobCardProps {
    job: ServiceJob;
    onStatusUpdate?: (id: string, newStatus: ServiceJob['status']) => void;
    readonly?: boolean;
}

const JobCard: React.FC<JobCardProps> = ({ job, onStatusUpdate, readonly }) => (
    <div className={`p-4 rounded-lg border shadow-sm mb-3 transition-all bg-white border-slate-200`}>
        <div className="flex justify-between items-start mb-2">
            <span className="font-mono text-xs font-bold bg-slate-100 px-2 py-1 rounded text-slate-600">{job.registrationNumber}</span>
            <span className="text-xs text-slate-400">{job.dateIn}</span>
        </div>
        <h4 className="font-bold text-slate-800">{job.vehicleModel}</h4>
        <p className="text-sm text-slate-500 mb-2">{job.customerName}</p>
        
        <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-medium px-2 py-0.5 rounded bg-indigo-50 text-indigo-600 border border-indigo-100">{job.serviceType}</span>
            <span className="text-xs font-semibold text-slate-600">₹{job.estimatedCost}</span>
        </div>

        {!readonly && onStatusUpdate ? (
            <select 
                className={`w-full text-xs font-semibold p-1.5 rounded border outline-none cursor-pointer ${getStatusColor(job.status)}`}
                value={job.status}
                onChange={(e) => onStatusUpdate(job.id, e.target.value as ServiceJob['status'])}
            >
                <option value="Pending">Pending</option>
                <option value="In Progress">In Progress</option>
                <option value="Washing">Washing</option>
                <option value="Ready">Ready</option>
                <option value="Delivered">Delivered</option>
            </select>
        ) : (
            <div className={`text-xs font-bold p-1.5 rounded border text-center ${getStatusColor(job.status)}`}>
                {job.status}
            </div>
        )}
    </div>
);

export const Services: React.FC = () => {
  const [jobs, setJobs] = useState<ServiceJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  
  // History Mode
  const [showHistory, setShowHistory] = useState(false);
  const [historySearch, setHistorySearch] = useState('');
  const [historyResults, setHistoryResults] = useState<ServiceJob[]>([]);

  useEffect(() => {
    loadJobs();
  }, []);

  const loadJobs = async () => {
    setLoading(true);
    const data = await api.services.getJobs();
    setJobs(data);
    setLoading(false);
  };

  const handleStatusUpdate = async (id: string, newStatus: ServiceJob['status']) => {
      setJobs(prev => prev.map(j => j.id === id ? {...j, status: newStatus} : j));
      await api.services.updateJobStatus(id, newStatus);
  };

  const handleSearchHistory = () => {
      if(!historySearch) return;
      const lowerSearch = historySearch.toLowerCase();
      // Search by Reg Number OR Customer Name
      const results = jobs.filter(j => 
          j.registrationNumber.toLowerCase().includes(lowerSearch) || 
          j.customerName.toLowerCase().includes(lowerSearch)
      );
      setHistoryResults(results);
  };

  const filteredJobs = jobs.filter(j => 
      j.customerName.toLowerCase().includes(filter.toLowerCase()) || 
      j.registrationNumber.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="p-8 space-y-6 ml-64 bg-slate-50 min-h-screen">
      <div className="flex justify-between items-center">
        <div>
            <h1 className="text-3xl font-bold text-slate-900">Service Workshop</h1>
            <p className="text-slate-500">Track repairs and view vehicle history.</p>
        </div>
        <div className="flex gap-3">
             {showHistory ? (
                 <button onClick={() => setShowHistory(false)} className="bg-slate-200 text-slate-700 px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-slate-300">
                     <ArrowLeft size={18} /> Back to Board
                 </button>
             ) : (
                 <button onClick={() => setShowHistory(true)} className="bg-slate-800 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-slate-900 shadow-sm">
                     <History size={18} /> Vehicle History
                 </button>
             )}
        </div>
      </div>

      {showHistory ? (
          <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-100 min-h-[600px]">
              <h2 className="text-xl font-bold mb-6">Service History Lookup</h2>
              <div className="flex gap-4 mb-8 max-w-lg">
                  <input 
                    className="flex-1 border p-2 rounded" 
                    placeholder="Enter Reg. Number OR Customer Name" 
                    value={historySearch}
                    onChange={e => setHistorySearch(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSearchHistory()}
                  />
                  <button onClick={handleSearchHistory} className="bg-blue-600 text-white px-4 rounded font-bold flex items-center gap-2">
                      <Search size={18} /> Search
                  </button>
              </div>

              {historyResults.length > 0 ? (
                  <div className="space-y-4">
                      {historyResults.map(job => (
                          <div key={job.id} className="border-b pb-4 flex justify-between items-center">
                              <div>
                                  <p className="font-bold text-lg">{job.customerName}</p>
                                  <p className="text-sm font-mono bg-slate-100 inline-block px-1 rounded text-slate-600 mb-1">{job.registrationNumber}</p>
                                  <p className="text-sm text-slate-500">{job.vehicleModel} - {job.serviceType}</p>
                                  <p className="text-xs text-slate-400">{job.dateIn}</p>
                              </div>
                              <div className="text-right">
                                  <span className={`px-3 py-1 rounded text-xs font-bold block w-fit ml-auto mb-1 ${getStatusColor(job.status)}`}>{job.status}</span>
                                  <span className="font-bold text-slate-700">₹{job.estimatedCost.toLocaleString()}</span>
                              </div>
                          </div>
                      ))}
                  </div>
              ) : (
                  <div className="text-slate-400 italic flex flex-col items-center justify-center h-40 border-2 border-dashed rounded-lg">
                      <Search size={32} className="mb-2 opacity-20"/>
                      {historySearch ? 'No records found matching your search.' : 'Enter details to search history.'}
                  </div>
              )}
          </div>
      ) : (
          /* Kanban Board */
          <>
            <div className="relative mb-4 max-w-sm">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                    type="text" 
                    placeholder="Search Live Jobs..." 
                    className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 h-[calc(100vh-220px)] overflow-hidden">
                {['Pending', 'In Progress', 'Washing', 'Ready'].map(status => (
                    <div key={status} className="flex flex-col bg-slate-100/50 rounded-xl p-2 h-full">
                        <div className="p-2 mb-2 flex items-center gap-2 font-bold border-b border-slate-200 text-slate-700">
                           {status} <span className="bg-slate-200 px-2 rounded-full text-xs">{filteredJobs.filter(j => j.status === status).length}</span>
                        </div>
                        <div className="flex-1 overflow-y-auto px-1">
                            {filteredJobs.filter(j => j.status === status).map(job => (
                                <JobCard key={job.id} job={job} onStatusUpdate={handleStatusUpdate} />
                            ))}
                        </div>
                    </div>
                ))}
            </div>
          </>
      )}
    </div>
  );
};
