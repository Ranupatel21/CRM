import React, { useState } from 'react';
import { User } from '../types';
import { MOCK_USERS } from '../constants';
import { Lock, User as UserIcon } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [selectedUserId, setSelectedUserId] = useState(MOCK_USERS[0].id);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = MOCK_USERS.find(u => u.id === selectedUserId);
    if (user) onLogin(user);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden">
        <div className="p-8 bg-blue-600 text-white text-center">
            <h1 className="text-3xl font-bold mb-2">Nexus CRM</h1>
            <p className="text-blue-100">Enterprise Management System</p>
        </div>

        <div className="p-8">
            <p className="text-center text-slate-500 mb-6 text-sm">Select a demo account to proceed:</p>
            
            <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                    <label className="block text-sm font-medium text-slate-700">Select User Role</label>
                    <div className="relative">
                        <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                        <select 
                            value={selectedUserId} 
                            onChange={(e) => setSelectedUserId(e.target.value)}
                            className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg appearance-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white text-slate-700"
                        >
                            {MOCK_USERS.map(u => (
                                <option key={u.id} value={u.id}>
                                    {u.name} — {u.role} ({u.department})
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                <button 
                    type="submit" 
                    className="w-full bg-slate-900 text-white py-3 rounded-lg font-semibold hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
                >
                    <Lock size={18} />
                    Authenticate
                </button>
            </form>

            <div className="mt-6 pt-6 border-t border-slate-100 text-xs text-center text-slate-400">
                Secure Enterprise Environment &copy; 2023 Nexus Corp
            </div>
        </div>
      </div>
    </div>
  );
};