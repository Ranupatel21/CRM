
import React, { useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  PieChart, Pie, Cell
} from 'recharts';
import { User, Role, Lead, Invoice, Employee } from '../types';
import { AIModal } from '../components/AIModal';
import { CalendarView, CalendarEvent } from '../components/CalendarView';
import { DollarSign, TrendingUp, Users, AlertCircle } from 'lucide-react';

interface DashboardProps {
  user: User;
  data: {
    leads: Lead[];
    invoices?: Invoice[]; // Optional to handle if not passed immediately
    employees?: Employee[]; // Optional
    revenue: number;
    ticketCount: number;
    employeeCount: number;
  };
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export const Dashboard: React.FC<DashboardProps> = ({ user, data }) => {
  
  // Logic to filter data based on role
  const visibleLeads = useMemo(() => {
    if (user.role === Role.MD) return data.leads;
    if (user.role === Role.MANAGER && user.department === 'SALES') return data.leads;
    return data.leads.filter(l => l.assignedToId === user.id);
  }, [user, data.leads]);

  // Calendar Events Aggregation
  const calendarEvents = useMemo(() => {
    const events: CalendarEvent[] = [];
    
    // Add Leads Follow-ups
    visibleLeads.forEach(l => {
        if(l.nextFollowUp) {
            events.push({
                id: l.id,
                title: l.customerName,
                date: l.nextFollowUp,
                type: 'lead',
                status: l.status
            });
        }
    });

    // Add Invoices (If visible)
    if ((user.role === Role.MD || user.department === 'FINANCE') && data.invoices) {
        data.invoices.forEach(inv => {
            if(inv.dueDate) {
                events.push({
                    id: inv.id,
                    title: `${inv.clientName} (₹${(inv.amount/100000).toFixed(1)}L)`,
                    date: inv.dueDate,
                    type: 'invoice',
                    status: inv.status
                });
            }
        });
    }

    // Add HR Reviews (If visible)
    if ((user.role === Role.MD || user.department === 'HR') && data.employees) {
        data.employees.forEach(emp => {
            if(emp.nextReviewDate) {
                events.push({
                    id: emp.id,
                    title: `Review: ${emp.name}`,
                    date: emp.nextReviewDate,
                    type: 'review',
                });
            }
        });
    }

    return events;
  }, [visibleLeads, data.invoices, data.employees, user]);

  // Calculate Status Distribution
  const statusData = useMemo(() => {
    const counts: Record<string, number> = {};
    visibleLeads.forEach(l => {
      counts[l.status] = (counts[l.status] || 0) + 1;
    });
    return Object.keys(counts).map(key => ({ name: key, value: counts[key] }));
  }, [visibleLeads]);

  // KPI Cards
  const StatCard = ({ title, value, icon: Icon, color, subtitle }: any) => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm font-medium text-slate-500 mb-1">{title}</p>
          <h3 className="text-2xl font-bold text-slate-900">{value}</h3>
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon size={20} className="text-white" />
        </div>
      </div>
      {subtitle && <p className="text-xs text-slate-400 mt-4">{subtitle}</p>}
    </div>
  );

  return (
    <div className="p-8 space-y-8 ml-64 bg-slate-50 min-h-screen">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Welcome back, {user.name.split(' ')[0]}</h1>
          <p className="text-slate-500 mt-1">Here's what's happening in {user.role === Role.MD ? 'the company' : 'your department'} today.</p>
        </div>
        <AIModal contextData={{ userRole: user.role, visibleLeads, statusData, calendarEvents }} buttonLabel="Analyze Dashboard" />
      </header>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Pipeline Value" 
          value={`₹${(visibleLeads.reduce((acc, curr) => acc + curr.value, 0) / 100000).toFixed(1)} Lakhs`} 
          icon={DollarSign} 
          color="bg-green-500"
          subtitle="Based on active leads"
        />
        <StatCard 
          title="Active Leads" 
          value={visibleLeads.length} 
          icon={TrendingUp} 
          color="bg-blue-500"
          subtitle="+12% from last month"
        />
        {(user.role === Role.MD || user.role === Role.MANAGER) && (
           <StatCard 
             title="Team Size" 
             value={data.employeeCount} 
             icon={Users} 
             color="bg-purple-500"
             subtitle="Active employees"
           />
        )}
        <StatCard 
           title="Pending Issues" 
           value={data.ticketCount} 
           icon={AlertCircle} 
           color="bg-amber-500"
           subtitle="Open support tickets"
         />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Main Chart Area */}
          <div className="xl:col-span-2 space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Lead Status Distribution */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 h-80">
                <h3 className="text-lg font-bold text-slate-800 mb-4">Lead Status Distribution</h3>
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                    <Pie
                        data={statusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                        label
                    >
                        {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </Pie>
                    <Tooltip />
                    <Legend verticalAlign="bottom" height={36}/>
                    </PieChart>
                </ResponsiveContainer>
                </div>

                {/* Deal Value Bar Chart */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 h-80">
                <h3 className="text-lg font-bold text-slate-800 mb-4">Deal Value by Client (in Lakhs)</h3>
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={visibleLeads}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis dataKey="customerName" tick={{fontSize: 12}} tickLine={false} />
                    <YAxis tickLine={false} tickFormatter={(value) => `₹${value/100000}L`} />
                    <Tooltip 
                        cursor={{fill: '#f8fafc'}}
                        contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                        formatter={(value: number) => [`₹${value.toLocaleString()}`, 'Value']}
                    />
                    <Bar dataKey="value" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={40} />
                    </BarChart>
                </ResponsiveContainer>
                </div>
            </div>

            {/* Recent List */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-100">
                <h3 className="text-lg font-bold text-slate-800">Recent Active Leads</h3>
                </div>
                <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-600">
                    <thead className="bg-slate-50 text-xs uppercase font-semibold text-slate-500">
                    <tr>
                        <th className="px-6 py-4">Customer</th>
                        <th className="px-6 py-4">Value</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4">Last Activity</th>
                    </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                    {visibleLeads.slice(0, 5).map((lead) => (
                        <tr key={lead.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4 font-medium text-slate-900">{lead.customerName}</td>
                        <td className="px-6 py-4">₹{lead.value.toLocaleString()}</td>
                        <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium 
                            ${lead.status === 'Won' ? 'bg-green-100 text-green-700' : 
                                lead.status === 'Lost' ? 'bg-red-100 text-red-700' : 
                                'bg-blue-100 text-blue-700'}`}>
                            {lead.status}
                            </span>
                        </td>
                        <td className="px-6 py-4 text-slate-400">{lead.lastActivity}</td>
                        </tr>
                    ))}
                    </tbody>
                </table>
                </div>
            </div>
          </div>

          {/* Right Column: Calendar */}
          <div className="xl:col-span-1 h-[680px]">
            <CalendarView events={calendarEvents} title="Upcoming Events" />
          </div>
      </div>
    </div>
  );
};
