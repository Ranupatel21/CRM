
import React, { useState, useEffect, useMemo } from 'react';
import { User, Lead, Role, Vehicle, TestDrive, Quotation, Booking } from '../types';
import { AIModal } from '../components/AIModal';
import { Search, Filter, X, LayoutGrid, Calendar as CalendarIcon, CarFront, FileText, Clipboard, Download, Plus, Save, Trash2, Printer, CheckCircle, CreditCard, Tag, Phone, Clock, User as UserIcon, Users, PieChart as PieChartIcon, BarChart3 } from 'lucide-react';
import { api } from '../services/api';

interface SalesProps {
  user: User;
  leads: Lead[];
  refreshLeads: () => void;
}

export const Sales = ({ user, leads, refreshLeads }: SalesProps) => {
  const [activeTab, setActiveTab] = useState<'pipeline' | 'inventory' | 'testdrives' | 'quotations' | 'bookings'>('pipeline');
  const [filter, setFilter] = useState('');
  const [inventorySearch, setInventorySearch] = useState('');
  const [showInquiryModal, setShowInquiryModal] = useState(false);
  
  // Data State
  const [inventory, setInventory] = useState<Vehicle[]>([]);
  const [testDrives, setTestDrives] = useState<TestDrive[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);

  // Selected Lead for Detail View
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);

  // Search States for Dropdowns
  const [driveSearch, setDriveSearch] = useState('');
  const [quoteSearch, setQuoteSearch] = useState('');
  const [bookingSearch, setBookingSearch] = useState('');

  // Quotation State
  const [quoteForm, setQuoteForm] = useState({
      customerName: '',
      vehicleId: '',
      exShowroomPrice: 0
  });
  const [generatedQuote, setGeneratedQuote] = useState<Quotation | null>(null);

  // Booking State
  const [bookingForm, setBookingForm] = useState({
      customerName: '',
      phone: '',
      vehicleId: '',
      discount: 0,
      accessoriesList: '',
      accessoriesCost: 0,
      bookingAmountPaid: 50000
  });
  const [recentBooking, setRecentBooking] = useState<Booking | null>(null);

  // New Test Drive Form
  const [driveForm, setDriveForm] = useState({
      customerName: '',
      vehicleModel: '',
      date: '',
      timeSlot: '10:00 AM'
  });

  // Toyota Inquiry Form State
  const [inquiryForm, setInquiryForm] = useState({
      name: '',
      number: '',
      vehicle: 'Toyota',
      model: '',
      color: '',
      time: 'This Month'
  });

  useEffect(() => {
    // Initial data fetch based on tab
    if (activeTab === 'inventory' || activeTab === 'quotations' || activeTab === 'bookings') {
        api.sales.getInventory().then(data => setInventory(data || []));
    }
    if (activeTab === 'testdrives') {
        api.sales.getTestDrives().then(data => setTestDrives(data || []));
    }
    if (activeTab === 'bookings') {
        api.sales.getBookings().then(data => setBookings(data || []));
    }
  }, [activeTab]);

  // Permission check
  const visibleLeads = leads.filter(l => {
    const matchesSearch = l.customerName.toLowerCase().includes(filter.toLowerCase()) || l.company.toLowerCase().includes(filter.toLowerCase());
    if (user.role === Role.EMPLOYEE) {
      return matchesSearch && l.assignedToId === user.id;
    }
    return matchesSearch;
  });

  // --- HELPER: Parse Inquiry Details ---
  const parseLeadDetails = (companyString: string) => {
      try {
          if (!companyString) return { model: '', phone: '' };
          const parts = companyString.split('(Ph:');
          const phone = parts[1]?.replace(')', '').trim() || '';
          const vehiclePart = parts[0]?.trim() || '';
          const cleanVehicle = vehiclePart.replace('Toyota ', '').split('-')[0]?.trim();
          return { model: cleanVehicle, phone };
      } catch (e) {
          return { model: '', phone: '' };
      }
  };

  // --- AUTO-FILL HANDLERS ---
  const handleDriveLeadSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const selectedName = e.target.value;
      const lead = leads.find(l => l.customerName === selectedName);
      if (lead) {
          const { model } = parseLeadDetails(lead.company);
          setDriveForm({
              ...driveForm,
              customerName: lead.customerName,
              vehicleModel: model || driveForm.vehicleModel
          });
      } else {
          setDriveForm({ ...driveForm, customerName: selectedName });
      }
  };

  const handleQuoteLeadSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const selectedName = e.target.value;
      const lead = leads.find(l => l.customerName === selectedName);
      if (lead) {
           setQuoteForm({ ...quoteForm, customerName: lead.customerName });
           const { model } = parseLeadDetails(lead.company);
           if (model) {
               const matchingVehicle = inventory.find(v => v.model.includes(model) && v.status === 'Available');
               if (matchingVehicle) {
                   setQuoteForm(prev => ({ ...prev, customerName: lead.customerName, vehicleId: matchingVehicle.id, exShowroomPrice: matchingVehicle.price }));
               }
           }
      } else {
           setQuoteForm({ ...quoteForm, customerName: selectedName });
      }
  };

  const handleBookingLeadSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const selectedName = e.target.value;
      const lead = leads.find(l => l.customerName === selectedName);
      if (lead) {
          const { phone, model } = parseLeadDetails(lead.company);
          setBookingForm(prev => ({
              ...prev,
              customerName: lead.customerName,
              phone: phone || prev.phone
          }));
          if (model) {
             const matchingVehicle = inventory.find(v => v.model.includes(model) && v.status === 'Available');
             if (matchingVehicle) {
                 setBookingForm(prev => ({ ...prev, customerName: lead.customerName, phone: phone || prev.phone, vehicleId: matchingVehicle.id }));
             }
          }
      } else {
          setBookingForm(prev => ({ ...prev, customerName: selectedName }));
      }
  };

  // --- STANDARD HANDLERS ---
  const handleStatusUpdate = async (id: string, newStatus: Lead['status']) => {
    await api.sales.updateLeadStatus(id, newStatus);
    if(selectedLead && selectedLead.id === id) {
        setSelectedLead({...selectedLead, status: newStatus});
    }
    refreshLeads();
  };

  const handleInquirySubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      const interestDetails = `${inquiryForm.vehicle} ${inquiryForm.model} - ${inquiryForm.color} (Ph: ${inquiryForm.number})`;
      await api.sales.createLead({
          customerName: inquiryForm.name,
          company: interestDetails,
          value: 0, 
          status: 'New',
          assignedToId: user.id,
          lastActivity: new Date().toISOString().split('T')[0],
          nextFollowUp: inquiryForm.time === 'This Month' ? new Date().toISOString().split('T')[0] : undefined
      });
      setShowInquiryModal(false);
      refreshLeads();
      setInquiryForm({ name: '', number: '', vehicle: 'Toyota', model: '', color: '', time: 'This Month' });
  };

  // --- INVENTORY HANDLERS ---
  const handleInventoryChange = async (id: string, field: keyof Vehicle, value: any) => {
      const updatedList = inventory.map(v => v.id === id ? { ...v, [field]: value } : v);
      setInventory(updatedList);
      await api.sales.updateVehicle(id, { [field]: value });
  };

  const handleAddInventoryRow = async () => {
      const newVehicle = await api.sales.addVehicle({
          vin: `TEMP-${Date.now()}`,
          model: 'New Car',
          fuelType: 'Petrol',
          variant: 'Base',
          color: 'White',
          price: 0,
          status: 'Available'
      });
      setInventory([...inventory, newVehicle]);
  };

  const downloadInventoryExcel = () => {
      const headers = ['VIN', 'Model', 'Fuel', 'Variant', 'Color', 'Price (INR)', 'Status'];
      const rows = inventory.map(v => [
          v.vin, v.model, v.fuelType, v.variant, v.color, v.price.toString(), v.status
      ]);
      const csvContent = "data:text/csv;charset=utf-8," + headers.join(",") + "\n" + rows.map(e => e.join(",")).join("\n");
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", "inventory_stock.csv");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };

  const filteredInventory = useMemo(() => {
    return inventory.filter(v => 
      (v.model || '').toLowerCase().includes(inventorySearch.toLowerCase()) || 
      (v.vin || '').toLowerCase().includes(inventorySearch.toLowerCase()) ||
      (v.color || '').toLowerCase().includes(inventorySearch.toLowerCase()) ||
      (v.fuelType || '').toLowerCase().includes(inventorySearch.toLowerCase())
    );
  }, [inventory, inventorySearch]);


  // --- TEST DRIVE HANDLERS ---
  const handleDriveChange = async (id: string, field: keyof TestDrive, value: any) => {
    const updated = testDrives.map(d => d.id === id ? { ...d, [field]: value } : d);
    setTestDrives(updated);
    await api.sales.updateTestDrive(id, { [field]: value });
  };

  const handleAddDrive = async () => {
      if(!driveForm.customerName) return;
      const newDrive = await api.sales.scheduleTestDrive({
          ...driveForm,
          status: 'Scheduled',
          assignedSalesPersonId: user.id
      });
      setTestDrives([...testDrives, newDrive]);
      setDriveForm({ customerName: '', vehicleModel: '', date: '', timeSlot: '10:00 AM' });
  };

  // --- QUOTATION HANDLERS ---
  const calculateOnRoad = () => {
      const ex = Number(quoteForm.exShowroomPrice);
      const insurance = ex * 0.05;
      const rto = ex * 0.10;
      const accessories = 25000;
      const total = ex + insurance + rto + accessories;
      
      const vehicle = inventory.find(v => v.id === quoteForm.vehicleId);

      const quote: Quotation = {
          id: `Q-${Date.now()}`,
          customerName: quoteForm.customerName,
          vehicleId: quoteForm.vehicleId,
          exShowroomPrice: ex,
          insurance,
          registrationCharges: rto,
          accessories,
          totalOnRoadPrice: total,
          date: new Date().toISOString().split('T')[0]
      };
      setGeneratedQuote(quote);
      api.sales.saveQuotation(quote);
  };

  // --- BOOKING HANDLERS ---
  const handleCreateBooking = async () => {
      const vehicle = inventory.find(v => v.id === bookingForm.vehicleId);
      const basePrice = vehicle ? vehicle.price : 0;
      const finalPrice = basePrice + Number(bookingForm.accessoriesCost) - Number(bookingForm.discount);
      
      const newBooking = await api.sales.createBooking({
          ...bookingForm,
          vehicleDetails: vehicle ? `${vehicle.model} ${vehicle.variant}` : 'Unknown',
          basePrice,
          finalPrice,
          date: new Date().toISOString().split('T')[0]
      });
      setBookings([...bookings, newBooking]);
      setRecentBooking(newBooking);
      setBookingForm({
          customerName: '', phone: '', vehicleId: '', discount: 0, 
          accessoriesList: '', accessoriesCost: 0, bookingAmountPaid: 50000
      });
  };

  // --- RENDERERS ---

  const renderPipeline = () => {
      const stages = ['New', 'Contacted', 'Proposal', 'Won', 'Lost'];
      return (
        <div className="flex gap-4 h-full overflow-x-auto pb-4">
          {stages.map(stage => (
            <div key={stage} className="min-w-[280px] bg-slate-100 rounded-xl p-3 flex flex-col h-full">
              <div className="flex justify-between items-center mb-3 px-1">
                <h3 className="font-bold text-slate-700">{stage}</h3>
                <span className="bg-slate-200 text-slate-600 px-2 py-0.5 rounded-full text-xs font-bold">
                  {visibleLeads.filter(l => l.status === stage).length}
                </span>
              </div>
              <div className="flex-1 overflow-y-auto space-y-3">
                {visibleLeads.filter(l => l.status === stage).map(lead => (
                  <div 
                    key={lead.id} 
                    onClick={() => setSelectedLead(lead)}
                    className="bg-white p-4 rounded-lg shadow-sm border border-slate-200 cursor-pointer hover:shadow-md transition-all group"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-bold text-slate-800">{lead.customerName}</h4>
                      {lead.nextFollowUp && (
                          <span className="text-[10px] bg-red-50 text-red-500 px-1.5 py-0.5 rounded flex items-center gap-1">
                             <Clock size={10} /> {lead.nextFollowUp}
                          </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 mb-2 truncate" title={lead.company}>{lead.company}</p>
                    <div className="flex justify-between items-center text-xs text-slate-400">
                      <span>{lead.lastActivity}</span>
                      <UserIcon size={14} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      );
  };

  const renderInventory = () => (
      <div className="flex flex-col h-full gap-4">
          {/* Table Section */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-100 flex flex-col flex-1 overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50 shrink-0">
                <div className="flex gap-4">
                    <h3 className="font-bold text-slate-800 flex items-center gap-2"><CarFront size={20}/> Vehicle Stock Sheet</h3>
                    <div className="relative">
                        <Search className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                        <input 
                            className="pl-8 pr-4 py-1 text-sm border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 w-64" 
                            placeholder="Search VIN, Model, Color, Fuel..."
                            value={inventorySearch}
                            onChange={(e) => setInventorySearch(e.target.value)}
                        />
                    </div>
                </div>
                <div className="flex gap-2">
                    <button onClick={handleAddInventoryRow} className="text-xs bg-blue-600 text-white px-3 py-1.5 rounded hover:bg-blue-700 flex items-center gap-1"><Plus size={14}/> Add Row</button>
                    <button onClick={downloadInventoryExcel} className="text-xs bg-emerald-600 text-white px-3 py-1.5 rounded hover:bg-emerald-700 flex items-center gap-1"><Download size={14}/> Download Excel</button>
                </div>
            </div>
            <div className="overflow-auto flex-1">
                <table className="w-full text-left text-sm border-collapse">
                    <thead className="bg-slate-100 text-slate-500 font-semibold sticky top-0 z-10 shadow-sm">
                        <tr>
                            <th className="border-r px-4 py-2 w-32">VIN / Chassis</th>
                            <th className="border-r px-4 py-2 w-48">Model</th>
                            <th className="border-r px-4 py-2 w-32">Fuel Type</th>
                            <th className="border-r px-4 py-2 w-40">Variant</th>
                            <th className="border-r px-4 py-2 w-32">Color</th>
                            <th className="border-r px-4 py-2 w-32">Price (INR)</th>
                            <th className="px-4 py-2 w-32">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {filteredInventory.map(v => (
                            <tr key={v.id} className="hover:bg-blue-50 transition-colors group">
                                <td className="p-0 border-r">
                                    <input 
                                        className="w-full px-4 py-2 bg-transparent outline-none focus:bg-white focus:ring-2 focus:ring-inset focus:ring-blue-500 font-mono text-xs"
                                        value={v.vin}
                                        onChange={(e) => handleInventoryChange(v.id, 'vin', e.target.value)}
                                    />
                                </td>
                                <td className="p-0 border-r">
                                    <input 
                                        className="w-full px-4 py-2 bg-transparent outline-none focus:bg-white focus:ring-2 focus:ring-inset focus:ring-blue-500 font-medium"
                                        value={v.model}
                                        onChange={(e) => handleInventoryChange(v.id, 'model', e.target.value)}
                                    />
                                </td>
                                <td className="p-0 border-r">
                                    <select 
                                        className="w-full px-4 py-2 bg-transparent outline-none focus:bg-white focus:ring-2 focus:ring-inset focus:ring-blue-500 cursor-pointer"
                                        value={v.fuelType}
                                        onChange={(e) => handleInventoryChange(v.id, 'fuelType', e.target.value)}
                                    >
                                        <option value="Petrol">Petrol</option>
                                        <option value="Diesel">Diesel</option>
                                        <option value="Hybrid">Hybrid</option>
                                        <option value="Electric">Electric</option>
                                    </select>
                                </td>
                                <td className="p-0 border-r">
                                    <input 
                                        className="w-full px-4 py-2 bg-transparent outline-none focus:bg-white focus:ring-2 focus:ring-inset focus:ring-blue-500"
                                        value={v.variant}
                                        onChange={(e) => handleInventoryChange(v.id, 'variant', e.target.value)}
                                    />
                                </td>
                                <td className="p-0 border-r">
                                    <input 
                                        className="w-full px-4 py-2 bg-transparent outline-none focus:bg-white focus:ring-2 focus:ring-inset focus:ring-blue-500"
                                        value={v.color}
                                        onChange={(e) => handleInventoryChange(v.id, 'color', e.target.value)}
                                    />
                                </td>
                                <td className="p-0 border-r">
                                    <input 
                                        type="number"
                                        className="w-full px-4 py-2 bg-transparent outline-none focus:bg-white focus:ring-2 focus:ring-inset focus:ring-blue-500 text-right font-mono"
                                        value={v.price}
                                        onChange={(e) => handleInventoryChange(v.id, 'price', parseInt(e.target.value))}
                                    />
                                </td>
                                <td className="p-0">
                                    <select 
                                        className={`w-full px-4 py-2 outline-none cursor-pointer font-bold text-xs uppercase
                                            ${v.status === 'Available' ? 'text-green-600 bg-green-50/50' : v.status === 'Booked' ? 'text-amber-600 bg-amber-50/50' : 'text-slate-400 bg-slate-50'}`}
                                        value={v.status}
                                        onChange={(e) => handleInventoryChange(v.id, 'status', e.target.value)}
                                    >
                                        <option value="Available">Available</option>
                                        <option value="Booked">Booked</option>
                                        <option value="Sold">Sold</option>
                                    </select>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
      </div>
  );

  return (
    <div className="p-8 space-y-6 ml-64 bg-slate-50 min-h-screen">
      {/* HEADER */}
      <div className="flex justify-between items-center">
        <div>
           <h1 className="text-3xl font-bold text-slate-900">Sales & Showroom</h1>
           <p className="text-slate-500">Manage inquiries, inventory, and bookings.</p>
        </div>
        <div className="flex gap-2">
           <AIModal contextData={{ leads: visibleLeads, inventory }} buttonLabel="Sales Insights" />
           <button 
             onClick={() => setShowInquiryModal(true)} 
             className="bg-red-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-red-700 shadow-sm"
            >
             <CarFront size={18} /> Vehicle Inquiry
           </button>
        </div>
      </div>

      {/* TABS */}
      <div className="flex gap-1 bg-white p-1 rounded-xl shadow-sm border border-slate-100 w-fit">
         {[
             {id: 'pipeline', label: 'Inquiry Pipeline', icon: Filter},
             {id: 'inventory', label: 'Inventory (Stock)', icon: LayoutGrid},
             {id: 'testdrives', label: 'Test Drives', icon: CalendarIcon},
             {id: 'quotations', label: 'Quotation', icon: FileText},
             {id: 'bookings', label: 'Bookings', icon: CheckCircle},
         ].map(tab => (
             <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeTab === tab.id ? 'bg-slate-900 text-white shadow' : 'text-slate-500 hover:bg-slate-100'
                }`}
             >
                 <tab.icon size={16} /> {tab.label}
             </button>
         ))}
      </div>

      {/* CONTENT AREA */}
      <div className="h-[calc(100vh-240px)] min-h-[500px]">
         {activeTab === 'pipeline' && (
             <div className="h-full flex flex-col">
                 <div className="mb-4 flex gap-2">
                     <div className="relative flex-1 max-w-sm">
                         <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                         <input 
                             placeholder="Search Inquiries..." 
                             className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200"
                             value={filter}
                             onChange={e => setFilter(e.target.value)}
                         />
                     </div>
                 </div>
                 <div className="flex-1 overflow-hidden">
                    {renderPipeline()}
                 </div>
             </div>
         )}

         {activeTab === 'inventory' && renderInventory()}

         {activeTab === 'testdrives' && (
             <div className="bg-white rounded-xl shadow-sm border border-slate-100 flex flex-col h-full overflow-hidden">
                 <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                    <h3 className="font-bold text-slate-800">Test Drive Schedule</h3>
                 </div>
                 
                 {/* Quick Add Row */}
                 <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex gap-2 items-end">
                     <div className="flex-1 space-y-1">
                        <label className="text-xs font-bold text-slate-500 uppercase">Select Inquiry</label>
                        <input 
                             className="w-full text-xs border p-1 rounded mb-1"
                             placeholder="Filter Names..."
                             value={driveSearch}
                             onChange={e => setDriveSearch(e.target.value)}
                         />
                        <select 
                            className="w-full border rounded px-3 py-2 text-sm"
                            onChange={handleDriveLeadSelect}
                            value={driveForm.customerName}
                        >
                            <option value="">Select Customer...</option>
                            {leads.filter(l => l.customerName.toLowerCase().includes(driveSearch.toLowerCase())).map(l => (
                                <option key={l.id} value={l.customerName}>{l.customerName} - {l.company}</option>
                            ))}
                        </select>
                     </div>
                     <div className="flex-1 space-y-1">
                         <label className="text-xs font-bold text-slate-500 uppercase">Vehicle</label>
                         <input 
                            className="w-full border rounded px-3 py-2 text-sm"
                            placeholder="e.g. Fortuner"
                            value={driveForm.vehicleModel}
                            onChange={(e) => setDriveForm({...driveForm, vehicleModel: e.target.value})}
                         />
                     </div>
                     <div className="w-40 space-y-1">
                         <label className="text-xs font-bold text-slate-500 uppercase">Date</label>
                         <input 
                            type="date"
                            className="w-full border rounded px-3 py-2 text-sm"
                            value={driveForm.date}
                            onChange={(e) => setDriveForm({...driveForm, date: e.target.value})}
                         />
                     </div>
                     <div className="w-32 space-y-1">
                         <label className="text-xs font-bold text-slate-500 uppercase">Time</label>
                         <select 
                            className="w-full border rounded px-3 py-2 text-sm"
                            value={driveForm.timeSlot}
                            onChange={(e) => setDriveForm({...driveForm, timeSlot: e.target.value})}
                         >
                             {['10:00 AM', '11:00 AM', '12:00 PM', '02:00 PM', '04:00 PM'].map(t => <option key={t}>{t}</option>)}
                         </select>
                     </div>
                     <button onClick={handleAddDrive} className="bg-slate-900 text-white px-4 py-2 rounded text-sm font-bold hover:bg-slate-800">Add Schedule</button>
                 </div>

                 {/* Editable Table */}
                 <div className="flex-1 overflow-auto">
                     <table className="w-full text-left text-sm">
                         <thead className="bg-slate-100 text-slate-500 text-xs uppercase font-semibold">
                             <tr>
                                 <th className="px-6 py-3">Customer</th>
                                 <th className="px-6 py-3">Vehicle</th>
                                 <th className="px-6 py-3">Date</th>
                                 <th className="px-6 py-3">Time</th>
                                 <th className="px-6 py-3">Taken By</th>
                                 <th className="px-6 py-3">Status</th>
                             </tr>
                         </thead>
                         <tbody className="divide-y divide-slate-100">
                             {testDrives.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(drive => (
                                 <tr key={drive.id} className={`hover:bg-slate-50 ${drive.status === 'Completed' ? 'bg-green-50/30' : ''}`}>
                                     <td className="px-6 py-3 font-medium">
                                         <input className="bg-transparent w-full outline-none focus:border-b border-blue-500" value={drive.customerName} onChange={e => handleDriveChange(drive.id, 'customerName', e.target.value)} />
                                     </td>
                                     <td className="px-6 py-3">
                                         <input className="bg-transparent w-full outline-none focus:border-b border-blue-500" value={drive.vehicleModel} onChange={e => handleDriveChange(drive.id, 'vehicleModel', e.target.value)} />
                                     </td>
                                     <td className="px-6 py-3">
                                         <input type="date" className="bg-transparent outline-none focus:border-b border-blue-500" value={drive.date} onChange={e => handleDriveChange(drive.id, 'date', e.target.value)} />
                                     </td>
                                     <td className="px-6 py-3">
                                         <input className="bg-transparent w-20 outline-none focus:border-b border-blue-500" value={drive.timeSlot} onChange={e => handleDriveChange(drive.id, 'timeSlot', e.target.value)} />
                                     </td>
                                     <td className="px-6 py-3 text-xs text-slate-500">
                                         {user.name}
                                     </td>
                                     <td className="px-6 py-3">
                                         <select 
                                            className={`border-none bg-transparent font-bold text-xs cursor-pointer ${drive.status === 'Scheduled' ? 'text-blue-600' : drive.status === 'Completed' ? 'text-green-600' : 'text-red-500'}`}
                                            value={drive.status}
                                            onChange={(e) => handleDriveChange(drive.id, 'status', e.target.value)}
                                         >
                                             <option>Scheduled</option>
                                             <option>Completed</option>
                                             <option>Cancelled</option>
                                         </select>
                                     </td>
                                 </tr>
                             ))}
                         </tbody>
                     </table>
                 </div>
             </div>
         )}

         {activeTab === 'quotations' && (
             <div className="grid grid-cols-2 gap-6 h-full">
                 <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                     <h3 className="font-bold text-lg mb-4 flex items-center gap-2"><Clipboard/> Quote Generator</h3>
                     <div className="space-y-4">
                         <div>
                             <label className="block text-sm font-medium text-slate-700 mb-1">Select Inquiry</label>
                             <input 
                                 className="w-full text-xs border p-1 rounded mb-1 bg-slate-50"
                                 placeholder="Search Name..."
                                 value={quoteSearch}
                                 onChange={e => setQuoteSearch(e.target.value)}
                             />
                             <select 
                                className="w-full border rounded-lg px-3 py-2"
                                onChange={handleQuoteLeadSelect}
                                value={quoteForm.customerName}
                             >
                                 <option value="">-- Choose Lead --</option>
                                 {leads.filter(l => l.customerName.toLowerCase().includes(quoteSearch.toLowerCase())).map(l => (
                                     <option key={l.id} value={l.customerName}>{l.customerName}</option>
                                 ))}
                             </select>
                         </div>
                         <div>
                             <label className="block text-sm font-medium text-slate-700 mb-1">Select Vehicle Stock</label>
                             <select 
                                className="w-full border rounded-lg px-3 py-2"
                                value={quoteForm.vehicleId}
                                onChange={(e) => {
                                    const v = inventory.find(i => i.id === e.target.value);
                                    setQuoteForm({...quoteForm, vehicleId: e.target.value, exShowroomPrice: v ? v.price : 0})
                                }}
                             >
                                 <option value="">-- Choose Car --</option>
                                 {inventory.filter(v => v.status === 'Available').map(v => (
                                     <option key={v.id} value={v.id}>{v.model} {v.variant} - {v.color}</option>
                                 ))}
                             </select>
                         </div>
                         <div>
                             <label className="block text-sm font-medium text-slate-700 mb-1">Ex-Showroom Price (INR)</label>
                             <input 
                                type="number"
                                className="w-full border rounded-lg px-3 py-2 bg-slate-50"
                                value={quoteForm.exShowroomPrice}
                                readOnly
                             />
                         </div>
                         <button onClick={calculateOnRoad} className="w-full bg-indigo-600 text-white py-2 rounded-lg font-bold hover:bg-indigo-700">Calculate Quote</button>
                     </div>
                 </div>

                 <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 flex flex-col justify-center items-center">
                     {generatedQuote ? (
                         <div className="bg-white p-6 shadow-lg rounded w-full max-w-sm border-t-4 border-indigo-600">
                             <div className="text-center border-b pb-4 mb-4">
                                 <h2 className="text-2xl font-bold text-slate-800">Toyota Quotation</h2>
                                 <p className="text-sm text-slate-500">Date: {generatedQuote.date}</p>
                             </div>
                             <div className="space-y-2 text-sm mb-6">
                                 <p><span className="font-bold">Customer:</span> {generatedQuote.customerName}</p>
                                 <div className="flex justify-between"><span>Ex-Showroom:</span> <span>₹{generatedQuote.exShowroomPrice.toLocaleString()}</span></div>
                                 <div className="flex justify-between"><span>Insurance (5%):</span> <span>₹{generatedQuote.insurance.toLocaleString()}</span></div>
                                 <div className="flex justify-between"><span>RTO & Reg (10%):</span> <span>₹{generatedQuote.registrationCharges.toLocaleString()}</span></div>
                                 <div className="flex justify-between"><span>Accessories:</span> <span>₹{generatedQuote.accessories.toLocaleString()}</span></div>
                                 <div className="border-t pt-2 mt-2 flex justify-between font-bold text-lg text-indigo-700">
                                     <span>On-Road Price:</span>
                                     <span>₹{generatedQuote.totalOnRoadPrice.toLocaleString()}</span>
                                 </div>
                             </div>
                             <button className="w-full border border-slate-300 py-2 rounded flex items-center justify-center gap-2 hover:bg-slate-50">
                                 <Printer size={16}/> Print / Save PDF
                             </button>
                         </div>
                     ) : (
                         <div className="text-slate-400 text-center">
                             <FileText size={48} className="mx-auto mb-2 opacity-20"/>
                             <p>Select details to generate a price breakdown</p>
                         </div>
                     )}
                 </div>
             </div>
         )}

         {activeTab === 'bookings' && (
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full overflow-y-auto">
                 {/* Booking Form */}
                 <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                     <h3 className="font-bold text-lg mb-6 flex items-center gap-2 text-indigo-700"><CheckCircle/> New Booking Entry</h3>
                     <div className="space-y-4">
                         <div className="grid grid-cols-2 gap-4">
                             <div>
                                 <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Search Inquiry</label>
                                 <input 
                                     className="w-full text-xs border p-1 rounded mb-1 bg-slate-50"
                                     value={bookingSearch}
                                     onChange={e => setBookingSearch(e.target.value)}
                                     placeholder="Type name..."
                                 />
                                 <select 
                                     className="w-full border rounded px-3 py-2 text-sm"
                                     value={bookingForm.customerName}
                                     onChange={handleBookingLeadSelect}
                                 >
                                     <option value="">Direct Customer</option>
                                     {leads.filter(l => l.customerName.toLowerCase().includes(bookingSearch.toLowerCase())).map(l => (
                                         <option key={l.id} value={l.customerName}>{l.customerName}</option>
                                     ))}
                                 </select>
                             </div>
                             <div>
                                 <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Phone</label>
                                 <input 
                                     className="w-full border rounded px-3 py-2"
                                     value={bookingForm.phone}
                                     onChange={e => setBookingForm({...bookingForm, phone: e.target.value})}
                                 />
                             </div>
                         </div>
                         <div>
                             <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Select Vehicle (VIN)</label>
                             <select 
                                 className="w-full border rounded px-3 py-2 text-sm"
                                 value={bookingForm.vehicleId}
                                 onChange={e => setBookingForm({...bookingForm, vehicleId: e.target.value})}
                             >
                                 <option value="">-- Choose Available Car --</option>
                                 {inventory.filter(v => v.status === 'Available').map(v => (
                                     <option key={v.id} value={v.id}>{v.model} ({v.variant}) - {v.color} [{v.vin}]</option>
                                 ))}
                             </select>
                         </div>
                         <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Discount (₹)</label>
                                <input type="number" className="w-full border rounded px-3 py-2" value={bookingForm.discount} onChange={e => setBookingForm({...bookingForm, discount: parseInt(e.target.value) || 0})} />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Booking Amount (₹)</label>
                                <input type="number" className="w-full border rounded px-3 py-2" value={bookingForm.bookingAmountPaid} onChange={e => setBookingForm({...bookingForm, bookingAmountPaid: parseInt(e.target.value) || 0})} />
                            </div>
                         </div>
                         <div>
                             <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Accessories (Comma Sep)</label>
                             <input className="w-full border rounded px-3 py-2 mb-2" placeholder="Mats, Mudflaps, Cover..." value={bookingForm.accessoriesList} onChange={e => setBookingForm({...bookingForm, accessoriesList: e.target.value})} />
                             <input type="number" className="w-full border rounded px-3 py-2" placeholder="Total Acc. Cost" value={bookingForm.accessoriesCost} onChange={e => setBookingForm({...bookingForm, accessoriesCost: parseInt(e.target.value) || 0})} />
                         </div>
                         <button onClick={handleCreateBooking} className="w-full bg-green-600 text-white py-3 rounded-lg font-bold hover:bg-green-700 shadow-md">Confirm Booking & Generate Receipt</button>
                     </div>
                 </div>

                 {/* Receipt Preview */}
                 <div className="flex flex-col gap-4">
                     {recentBooking ? (
                         <div className="bg-white p-8 shadow-xl border border-slate-200 relative">
                             <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-red-500 to-red-600"></div>
                             <div className="flex justify-between items-start mb-8">
                                 <div>
                                     <h1 className="text-3xl font-bold text-slate-800 tracking-tight">Booking Receipt</h1>
                                     <p className="text-slate-500">Nexus Toyota Dealership</p>
                                 </div>
                                 <div className="text-right">
                                     <p className="font-mono text-sm">#{recentBooking.id}</p>
                                     <p className="text-sm text-slate-500">{recentBooking.date}</p>
                                 </div>
                             </div>

                             <div className="border-b-2 border-slate-100 pb-6 mb-6">
                                 <h3 className="text-xs font-bold text-slate-400 uppercase mb-2">Customer</h3>
                                 <p className="text-xl font-bold text-slate-800">{recentBooking.customerName}</p>
                                 <p className="text-slate-600">{recentBooking.phone}</p>
                             </div>

                             <div className="mb-6">
                                 <h3 className="text-xs font-bold text-slate-400 uppercase mb-2">Vehicle Details</h3>
                                 <p className="text-lg text-slate-800">{recentBooking.vehicleDetails}</p>
                             </div>

                             <div className="space-y-2 text-sm border-b border-slate-100 pb-4 mb-4">
                                 <div className="flex justify-between"><span>Base Price</span> <span>₹{recentBooking.basePrice.toLocaleString()}</span></div>
                                 <div className="flex justify-between text-slate-500"><span>Accessories ({recentBooking.accessoriesList})</span> <span>+ ₹{recentBooking.accessoriesCost.toLocaleString()}</span></div>
                                 <div className="flex justify-between text-green-600"><span>Discount Applied</span> <span>- ₹{recentBooking.discount.toLocaleString()}</span></div>
                                 <div className="flex justify-between font-bold text-lg pt-2 text-slate-800"><span>Total Price</span> <span>₹{recentBooking.finalPrice.toLocaleString()}</span></div>
                             </div>

                             <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                                 <div className="flex justify-between items-center mb-1">
                                     <span className="font-bold text-slate-600">Booking Amount Paid</span>
                                     <span className="font-bold text-xl text-green-600">₹{recentBooking.bookingAmountPaid.toLocaleString()}</span>
                                 </div>
                                 <div className="flex justify-between items-center text-xs text-slate-400">
                                     <span>Balance Due</span>
                                     <span>₹{(recentBooking.finalPrice - recentBooking.bookingAmountPaid).toLocaleString()}</span>
                                 </div>
                             </div>
                             
                             <div className="mt-8 text-center">
                                 <button onClick={() => window.print()} className="flex items-center justify-center gap-2 mx-auto text-slate-500 hover:text-slate-800">
                                     <Printer size={16}/> Print Customer Copy
                                 </button>
                             </div>
                         </div>
                     ) : (
                         <div className="flex-1 flex flex-col items-center justify-center bg-slate-50 border-2 border-dashed border-slate-200 rounded-xl text-slate-400">
                             <Tag size={48} className="mb-2 opacity-20"/>
                             <p>Complete booking form to view receipt</p>
                         </div>
                     )}
                 </div>
             </div>
         )}
      </div>

      {/* MODALS */}
      {showInquiryModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden">
                <div className="bg-red-600 p-4 flex justify-between items-center text-white">
                    <h3 className="font-bold flex items-center gap-2"><CarFront/> Vehicle Inquiry</h3>
                    <button onClick={() => setShowInquiryModal(false)}><X/></button>
                </div>
                <form onSubmit={handleInquirySubmit} className="p-6 space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Customer Name</label>
                            <input required className="w-full border rounded px-3 py-2" value={inquiryForm.name} onChange={e => setInquiryForm({...inquiryForm, name: e.target.value})} />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Mobile Number</label>
                            <input required className="w-full border rounded px-3 py-2" value={inquiryForm.number} onChange={e => setInquiryForm({...inquiryForm, number: e.target.value})} />
                        </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Vehicle</label>
                            <select className="w-full border rounded px-3 py-2" value={inquiryForm.vehicle} onChange={e => setInquiryForm({...inquiryForm, vehicle: e.target.value})}>
                                <option>Toyota</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Model</label>
                            <select className="w-full border rounded px-3 py-2" value={inquiryForm.model} onChange={e => setInquiryForm({...inquiryForm, model: e.target.value})}>
                                <option value="">Select...</option>
                                <option>Fortuner</option>
                                <option>Innova Hycross</option>
                                <option>Urban Cruiser Hyryder</option>
                                <option>Glanza</option>
                                <option>Camry</option>
                                <option>Hilux</option>
                                <option>Vellfire</option>
                            </select>
                        </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Color Preference</label>
                            <input className="w-full border rounded px-3 py-2" value={inquiryForm.color} onChange={e => setInquiryForm({...inquiryForm, color: e.target.value})} />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Time Duration</label>
                            <select className="w-full border rounded px-3 py-2" value={inquiryForm.time} onChange={e => setInquiryForm({...inquiryForm, time: e.target.value})}>
                                <option>This Month</option>
                                <option>Next Month</option>
                                <option>This Year</option>
                                <option>Next Year</option>
                            </select>
                        </div>
                    </div>
                    <button className="w-full bg-red-600 text-white font-bold py-3 rounded hover:bg-red-700">Submit Inquiry</button>
                </form>
            </div>
        </div>
      )}

      {selectedLead && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
                  <div className="p-4 border-b flex justify-between items-center bg-slate-50 rounded-t-xl">
                      <h3 className="font-bold">Inquiry Details</h3>
                      <button onClick={() => setSelectedLead(null)}><X size={20}/></button>
                  </div>
                  <div className="p-6 space-y-4">
                      <div className="flex items-center gap-3 mb-4">
                          <div className="bg-blue-100 p-3 rounded-full"><UserIcon size={24} className="text-blue-600"/></div>
                          <div>
                              <h2 className="text-xl font-bold">{selectedLead.customerName}</h2>
                              <span className={`text-xs px-2 py-0.5 rounded-full ${selectedLead.status === 'New' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100'}`}>{selectedLead.status}</span>
                          </div>
                      </div>
                      
                      {/* Parsed Details */}
                      <div className="bg-slate-50 p-4 rounded-lg space-y-2 text-sm border">
                          <p className="flex justify-between"><span className="text-slate-500">Vehicle Interest:</span> <span className="font-medium">{parseLeadDetails(selectedLead.company).model || 'N/A'}</span></p>
                          <p className="flex justify-between"><span className="text-slate-500">Phone:</span> <span className="font-medium">{parseLeadDetails(selectedLead.company).phone || 'N/A'}</span></p>
                          <p className="flex justify-between"><span className="text-slate-500">Planning:</span> <span className="font-medium">{selectedLead.nextFollowUp ? 'Specific Date' : 'Flexible'}</span></p>
                      </div>

                      <div className="grid grid-cols-3 gap-2 mt-4">
                          <button onClick={() => handleStatusUpdate(selectedLead.id, 'Contacted')} className="py-2 text-xs font-bold border rounded hover:bg-slate-50">Mark Contacted</button>
                          <button onClick={() => handleStatusUpdate(selectedLead.id, 'Won')} className="py-2 text-xs font-bold border border-green-200 bg-green-50 text-green-700 hover:bg-green-100">Mark Sold</button>
                          <button onClick={() => handleStatusUpdate(selectedLead.id, 'Lost')} className="py-2 text-xs font-bold border border-red-200 bg-red-50 text-red-700 hover:bg-red-100">Mark Lost</button>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
