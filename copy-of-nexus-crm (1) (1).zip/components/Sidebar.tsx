
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  DollarSign, 
  Users, 
  Briefcase, 
  Wrench, 
  Settings, 
  LogOut,
  PieChart,
  Database
} from 'lucide-react';
import { Role, Department, User } from '../types';

interface SidebarProps {
  user: User;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ user, onLogout }) => {
  const location = useLocation();
  const path = location.pathname;

  // Helper to check if a link is active
  const isActive = (p: string) => path === p ? 'bg-slate-800 text-blue-400 border-r-4 border-blue-400' : 'text-slate-400 hover:bg-slate-800 hover:text-white';

  // Permission Logic
  const canViewSales = user.role === Role.MD || user.department === Department.SALES;
  const canViewFinance = user.role === Role.MD || user.department === Department.FINANCE;
  const canViewHR = user.role === Role.MD || user.department === Department.HR;
  const canViewServices = user.role === Role.MD || user.department === Department.SERVICES;
  const isMD = user.role === Role.MD;

  return (
    <div className="h-screen w-64 bg-slate-900 text-white flex flex-col fixed left-0 top-0 shadow-xl z-50">
      <div className="p-6 border-b border-slate-800 flex items-center gap-3">
        <div className="bg-blue-600 p-2 rounded-lg">
            <PieChart size={24} className="text-white" />
        </div>
        <div>
            <h1 className="text-xl font-bold tracking-tight">Nexus CRM</h1>
            <p className="text-xs text-slate-500 uppercase tracking-wider">{user.role}</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-1">
          <li>
            <Link to="/" className={`flex items-center gap-3 px-6 py-3 transition-all ${isActive('/')}`}>
              <LayoutDashboard size={20} />
              <span>Dashboard</span>
            </Link>
          </li>

          {canViewSales && (
            <li>
              <Link to="/sales" className={`flex items-center gap-3 px-6 py-3 transition-all ${isActive('/sales')}`}>
                <DollarSign size={20} />
                <span>Sales & Inventory</span>
              </Link>
            </li>
          )}

          {canViewFinance && (
            <li>
              <Link to="/finance" className={`flex items-center gap-3 px-6 py-3 transition-all ${isActive('/finance')}`}>
                <PieChart size={20} />
                <span>Finance</span>
              </Link>
            </li>
          )}

          {canViewHR && (
            <li>
              <Link to="/hr" className={`flex items-center gap-3 px-6 py-3 transition-all ${isActive('/hr')}`}>
                <Users size={20} />
                <span>Human Resources</span>
              </Link>
            </li>
          )}

          {canViewServices && (
            <li>
              <Link to="/services" className={`flex items-center gap-3 px-6 py-3 transition-all ${isActive('/services')}`}>
                <Wrench size={20} />
                <span>Service Workshop</span>
              </Link>
            </li>
          )}

          {isMD && (
             <li>
                <Link to="/admin-data" className={`flex items-center gap-3 px-6 py-3 transition-all ${isActive('/admin-data')}`}>
                  <Database size={20} />
                  <span>Master Database</span>
                </Link>
             </li>
          )}
          
          <li className="mt-8 pt-8 border-t border-slate-800">
             <p className="px-6 text-xs font-semibold text-slate-500 uppercase mb-2">Account</p>
             <div className="px-6 py-2 flex items-center gap-3">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full border border-slate-600" />
                <div className="overflow-hidden">
                    <p className="text-sm font-medium truncate">{user.name}</p>
                    <p className="text-xs text-slate-500 truncate">{user.email}</p>
                </div>
             </div>
          </li>
        </ul>
      </nav>

      <div className="p-4 border-t border-slate-800">
        <button 
          onClick={onLogout}
          className="flex w-full items-center justify-center gap-2 bg-slate-800 hover:bg-red-600 hover:text-white text-slate-300 py-2 rounded-lg transition-colors text-sm font-medium"
        >
          <LogOut size={16} />
          Sign Out
        </button>
      </div>
    </div>
  );
};
