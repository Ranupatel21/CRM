
import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';

export interface CalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  type: 'lead' | 'invoice' | 'review' | 'generic';
  status?: string;
  value?: string | number;
}

interface CalendarViewProps {
  events: CalendarEvent[];
  title?: string;
}

export const CalendarView: React.FC<CalendarViewProps> = ({ events, title = "Schedule" }) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const getDaysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const getFirstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);
  
  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  const handlePrevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const handleNextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

  const getEventsForDay = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return events.filter(e => e.date === dateStr);
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'lead': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'invoice': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'review': return 'bg-purple-100 text-purple-700 border-purple-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden flex flex-col h-full">
      <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
        <div className="flex items-center gap-2">
           <CalendarIcon size={20} className="text-slate-500" />
           <h3 className="font-bold text-slate-800">{title}</h3>
        </div>
        <div className="flex items-center gap-4">
            <span className="font-semibold text-slate-700 w-32 text-center">{monthNames[month]} {year}</span>
            <div className="flex gap-1">
                <button onClick={handlePrevMonth} className="p-1 hover:bg-slate-200 rounded"><ChevronLeft size={20}/></button>
                <button onClick={handleNextMonth} className="p-1 hover:bg-slate-200 rounded"><ChevronRight size={20}/></button>
            </div>
        </div>
      </div>
      
      <div className="flex-1 p-4">
        {/* Days Header */}
        <div className="grid grid-cols-7 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
                <div key={d} className="text-center text-xs font-semibold text-slate-400 uppercase">{d}</div>
            ))}
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 grid-rows-5 gap-2 h-96">
            {/* Empty slots for previous month */}
            {Array.from({ length: firstDay }).map((_, i) => (
                <div key={`empty-${i}`} className="bg-slate-50/50 rounded-lg"></div>
            ))}
            
            {/* Days */}
            {Array.from({ length: daysInMonth }).map((_, i) => {
                const day = i + 1;
                const dayEvents = getEventsForDay(day);
                const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();

                return (
                    <div key={day} className={`border rounded-lg p-1.5 flex flex-col relative overflow-hidden transition-all hover:border-indigo-200 hover:shadow-sm ${isToday ? 'bg-indigo-50/30 border-indigo-100' : 'border-slate-100 bg-white'}`}>
                        <span className={`text-xs font-semibold mb-1 w-6 h-6 flex items-center justify-center rounded-full ${isToday ? 'bg-indigo-600 text-white' : 'text-slate-500'}`}>
                            {day}
                        </span>
                        
                        <div className="flex-1 overflow-y-auto space-y-1 scrollbar-hide">
                            {dayEvents.map((evt, idx) => (
                                <div 
                                    key={evt.id + idx} 
                                    className={`text-[10px] px-1.5 py-1 rounded border truncate font-medium ${getTypeColor(evt.type)}`}
                                    title={`${evt.title} (${evt.status})`}
                                >
                                    {evt.type === 'invoice' && '$'}
                                    {evt.title}
                                </div>
                            ))}
                        </div>
                    </div>
                );
            })}
        </div>
      </div>
      
      <div className="p-3 bg-slate-50 border-t border-slate-100 flex gap-4 text-xs text-slate-500 justify-center">
         <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-blue-500"></div> Lead Follow-up</div>
         <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-emerald-500"></div> Invoice Due</div>
         <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-purple-500"></div> Performance Review</div>
      </div>
    </div>
  );
};
