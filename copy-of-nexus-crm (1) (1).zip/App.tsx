
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { Sales } from './pages/Sales';
import { Finance } from './pages/Finance';
import { HR } from './pages/HR';
import { AdminData } from './pages/AdminData';
import { Sidebar } from './components/Sidebar';
import { User, Role, Department, Lead, Invoice, Employee, Ticket } from './types';
import { api } from './services/api';
import { MOCK_TICKETS } from './constants'; 
import { WifiOff } from 'lucide-react';

interface ProtectedRouteProps {
  children: React.ReactNode;
  user: User | null;
  requiredRole?: Role;
  requiredDept?: Department;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, user, requiredRole, requiredDept }) => {
  if (!user) return <Navigate to="/login" />;

  if (user.role === Role.MD) {
     return <>{children}</>;
  }

  if (requiredRole && user.role !== requiredRole) {
      return <Navigate to="/" />;
  }

  if (requiredDept && user.department !== requiredDept) {
      return <Navigate to="/" />;
  }

  return <>{children}</>;
};

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  
  const [leads, setLeads] = useState<Lead[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [tickets] = useState<Ticket[]>(MOCK_TICKETS);
  
  const [loading, setLoading] = useState(false);
  const [isOffline, setIsOffline] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('nexus_user');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
  }, []);

  useEffect(() => {
    if (currentUser) {
      setLoading(true);
      const fetchData = async () => {
        try {
          // Parallel fetch
          const [fetchedLeads, fetchedInvoices, fetchedEmployees, fetchedUsers] = await Promise.all([
            api.sales.getLeads(),
            api.finance.getInvoices(),
            api.hr.getEmployees(),
            api.users.getUsers()
          ]);
          
          setLeads(fetchedLeads);
          setInvoices(fetchedInvoices);
          setEmployees(fetchedEmployees);
          setUsers(fetchedUsers);
          
          // Check backend status
          setIsOffline(!api.system.isOnline());

        } catch (error) {
          console.error("Failed to load CRM data", error);
        } finally {
          setLoading(false);
        }
      };
      fetchData();
    }
  }, [currentUser]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('nexus_user', JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('nexus_user');
  };

  if (!currentUser) {
    return <Login onLogin={handleLogin} />;
  }

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <HashRouter>
      <div className="flex">
        <Sidebar user={currentUser} onLogout={handleLogout} />
        <main className="flex-1 relative">
          
          {isOffline && (
            <div className="absolute top-0 left-0 right-0 bg-amber-500 text-white text-xs font-bold px-4 py-1 flex items-center justify-center gap-2 z-[1000]">
                <WifiOff size={14} />
                <span>Backend Offline: Running in Browser Storage Mode</span>
            </div>
          )}

          <Routes>
            <Route path="/" element={
              <Dashboard 
                user={currentUser} 
                data={{
                  leads,
                  invoices,
                  employees, 
                  revenue: invoices.reduce((a,b) => a + b.amount, 0),
                  ticketCount: tickets.length,
                  employeeCount: employees.length
                }} 
              />
            } />
            
            <Route path="/sales" element={
              <ProtectedRoute user={currentUser} requiredDept={Department.SALES}>
                <Sales user={currentUser} leads={leads} refreshLeads={async () => {
                  const l = await api.sales.getLeads();
                  setLeads(l);
                  setIsOffline(!api.system.isOnline());
                }} />
              </ProtectedRoute>
            } />

            <Route path="/finance" element={
              <ProtectedRoute user={currentUser} requiredDept={Department.FINANCE}>
                <Finance 
                    invoices={invoices} 
                    refreshData={async () => {
                        const i = await api.finance.getInvoices();
                        setInvoices(i);
                        setIsOffline(!api.system.isOnline());
                    }}
                />
              </ProtectedRoute>
            } />

            <Route path="/hr" element={
              <ProtectedRoute user={currentUser} requiredDept={Department.HR}>
                <HR 
                    employees={employees} 
                    refreshData={async () => {
                        const e = await api.hr.getEmployees();
                        setEmployees(e);
                        setIsOffline(!api.system.isOnline());
                    }}
                />
              </ProtectedRoute>
            } />

            <Route path="/services" element={
                <ProtectedRoute user={currentUser} requiredDept={Department.SERVICES}>
                    <div className="p-8 ml-64 text-slate-600">Services Module (Placeholder)</div>
                </ProtectedRoute>
            } />

            <Route path="/admin-data" element={
                <ProtectedRoute user={currentUser} requiredRole={Role.MD}>
                   <AdminData data={{ users, leads, invoices, employees }} />
                </ProtectedRoute>
            } />
            
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </div>
    </HashRouter>
  );
};

export default App;
