
import { Lead, Invoice, Employee, PerformanceReview, User, Vehicle, ServiceJob, TestDrive, Quotation, LoanApplication, Booking } from '../types';
import { MOCK_LEADS, MOCK_INVOICES, MOCK_EMPLOYEES, MOCK_USERS, MOCK_VEHICLES, MOCK_SERVICE_JOBS } from '../constants';

// --- CONFIGURATION ---
const API_URL = 'http://localhost:5000/api';

// Storage Keys for Mock Mode
const KEYS = {
  LEADS: 'nexus_leads',
  INVOICES: 'nexus_invoices',
  EMPLOYEES: 'nexus_employees',
  USERS: 'nexus_users',
  VEHICLES: 'nexus_vehicles',
  SERVICE_JOBS: 'nexus_service_jobs',
  TEST_DRIVES: 'nexus_test_drives',
  QUOTATIONS: 'nexus_quotations',
  LOANS: 'nexus_loans',
  BOOKINGS: 'nexus_bookings'
};

// Helper to simulate network delay (Realism)
const delay = <T>(ms: number, value: T): Promise<T> => {
  return new Promise((resolve) => setTimeout(() => resolve(value), ms));
};

// --- Generic LocalStorage Data Handler (MOCK) ---
const getCollection = <T>(key: string, defaultData: T[]): T[] => {
  try {
    const stored = localStorage.getItem(key);
    if (!stored) {
        localStorage.setItem(key, JSON.stringify(defaultData));
        return defaultData;
    }
    return JSON.parse(stored);
  } catch (e) {
    return defaultData;
  }
};

const saveCollection = <T>(key: string, data: T[]) => {
  localStorage.setItem(key, JSON.stringify(data));
};

// --- ROBUST FETCH HELPER ---
// Tries to fetch from backend. If it fails, falls back to the mock implementation.
let isBackendOnline = true; // State tracker

const safeFetch = async <T>(
    endpoint: string, 
    options: RequestInit | undefined, 
    mockFallback: () => Promise<T>
): Promise<T> => {
    try {
        const res = await fetch(`${API_URL}${endpoint}`, options);
        if (!res.ok) throw new Error(`API Error: ${res.statusText}`);
        isBackendOnline = true;
        return await res.json();
    } catch (err) {
        if (isBackendOnline) {
             console.warn(`Backend unreachable (${endpoint}). Switching to Offline/Mock mode.`);
             isBackendOnline = false;
        }
        return mockFallback();
    }
};

// --- API IMPLEMENTATION ---

export const api = {
  system: {
    isOnline: () => isBackendOnline,
    seedDatabase: async (): Promise<void> => {
        // Try backend seed first
        try {
            await fetch(`${API_URL}/seed`, { method: 'POST' });
            isBackendOnline = true;
        } catch (e) {
            console.warn("Seeding local storage fallback.");
            isBackendOnline = false;
            // Reset local storage
            localStorage.setItem(KEYS.USERS, JSON.stringify(MOCK_USERS));
            localStorage.setItem(KEYS.LEADS, JSON.stringify(MOCK_LEADS));
            localStorage.setItem(KEYS.INVOICES, JSON.stringify(MOCK_INVOICES));
            localStorage.setItem(KEYS.EMPLOYEES, JSON.stringify(MOCK_EMPLOYEES));
            localStorage.setItem(KEYS.VEHICLES, JSON.stringify(MOCK_VEHICLES));
            localStorage.setItem(KEYS.SERVICE_JOBS, JSON.stringify(MOCK_SERVICE_JOBS));
            localStorage.removeItem(KEYS.TEST_DRIVES);
            localStorage.removeItem(KEYS.QUOTATIONS);
            localStorage.removeItem(KEYS.LOANS);
            localStorage.removeItem(KEYS.BOOKINGS);
        }
    }
  },
  users: {
    getUsers: async (): Promise<User[]> => {
        return safeFetch('/users', undefined, async () => {
            return delay(300, getCollection<User>(KEYS.USERS, MOCK_USERS));
        });
    }
  },
  sales: {
    getLeads: async (): Promise<Lead[]> => {
        return safeFetch('/sales/leads', undefined, async () => {
            return delay(400, getCollection<Lead>(KEYS.LEADS, MOCK_LEADS));
        });
    },
    getInventory: async (): Promise<Vehicle[]> => {
        return safeFetch('/sales/inventory', undefined, async () => {
            return delay(300, getCollection<Vehicle>(KEYS.VEHICLES, MOCK_VEHICLES));
        });
    },
    addVehicle: async (vehicle: Omit<Vehicle, 'id'>): Promise<Vehicle> => {
        return safeFetch('/sales/inventory', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(vehicle)
        }, async () => {
            const vehicles = getCollection<Vehicle>(KEYS.VEHICLES, MOCK_VEHICLES);
            const newV = { ...vehicle, id: `v${Date.now()}` };
            vehicles.push(newV);
            saveCollection(KEYS.VEHICLES, vehicles);
            return delay(400, newV);
        });
    },
    updateVehicle: async (id: string, updates: Partial<Vehicle>): Promise<Vehicle> => {
        return safeFetch(`/sales/inventory/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updates)
        }, async () => {
            const vehicles = getCollection<Vehicle>(KEYS.VEHICLES, MOCK_VEHICLES);
            const updated = vehicles.map(v => v.id === id ? { ...v, ...updates } : v);
            saveCollection(KEYS.VEHICLES, updated);
            // Return the specific updated item
            return delay(300, updated.find(v => v.id === id) as Vehicle);
        });
    },
    createLead: async (lead: Omit<Lead, 'id'>): Promise<Lead> => {
        return safeFetch('/sales/leads', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(lead)
        }, async () => {
            const leads = getCollection<Lead>(KEYS.LEADS, MOCK_LEADS);
            const newLead: Lead = { ...lead, id: `l${Date.now()}` };
            leads.push(newLead);
            saveCollection(KEYS.LEADS, leads);
            return delay(500, newLead);
        });
    },
    updateLeadStatus: async (id: string, status: Lead['status']): Promise<void> => {
        return safeFetch(`/sales/leads/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status, lastActivity: new Date().toISOString().split('T')[0] })
        }, async () => {
            const leads = getCollection<Lead>(KEYS.LEADS, MOCK_LEADS);
            const updated = leads.map(l => l.id === id ? { ...l, status, lastActivity: new Date().toISOString().split('T')[0] } : l);
            saveCollection(KEYS.LEADS, updated);
            return delay(300, undefined as void);
        });
    },
    // New Features
    getTestDrives: async (): Promise<TestDrive[]> => {
        return safeFetch('/sales/test-drives', undefined, async () => {
            return delay(300, getCollection<TestDrive>(KEYS.TEST_DRIVES, []));
        });
    },
    scheduleTestDrive: async (drive: Omit<TestDrive, 'id'>): Promise<TestDrive> => {
        return safeFetch('/sales/test-drives', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(drive)
        }, async () => {
            const drives = getCollection<TestDrive>(KEYS.TEST_DRIVES, []);
            const newDrive = { ...drive, id: `td${Date.now()}` };
            drives.push(newDrive);
            saveCollection(KEYS.TEST_DRIVES, drives);
            return delay(400, newDrive);
        });
    },
    updateTestDrive: async (id: string, updates: Partial<TestDrive>): Promise<TestDrive> => {
        return safeFetch(`/sales/test-drives/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updates)
        }, async () => {
            const drives = getCollection<TestDrive>(KEYS.TEST_DRIVES, []);
            const updated = drives.map(d => d.id === id ? { ...d, ...updates } : d);
            saveCollection(KEYS.TEST_DRIVES, updated);
            return delay(300, updated.find(d => d.id === id) as TestDrive);
        });
    },
    saveQuotation: async (quote: Omit<Quotation, 'id'>): Promise<Quotation> => {
        return safeFetch('/sales/quotations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(quote)
        }, async () => {
            const quotes = getCollection<Quotation>(KEYS.QUOTATIONS, []);
            const newQuote = { ...quote, id: `qt${Date.now()}` };
            quotes.push(newQuote);
            saveCollection(KEYS.QUOTATIONS, quotes);
            return delay(400, newQuote);
        });
    },
    getBookings: async (): Promise<Booking[]> => {
        return safeFetch('/sales/bookings', undefined, async () => {
            return delay(300, getCollection<Booking>(KEYS.BOOKINGS, []));
        });
    },
    createBooking: async (booking: Omit<Booking, 'id'>): Promise<Booking> => {
        return safeFetch('/sales/bookings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(booking)
        }, async () => {
            const bookings = getCollection<Booking>(KEYS.BOOKINGS, []);
            const newBooking = { ...booking, id: `bk${Date.now()}` };
            bookings.push(newBooking);
            saveCollection(KEYS.BOOKINGS, bookings);
            
            // Side effect: Update vehicle status in mock
            if(booking.vehicleId) {
                const vehicles = getCollection<Vehicle>(KEYS.VEHICLES, MOCK_VEHICLES);
                const updatedVehicles = vehicles.map(v => v.id === booking.vehicleId ? {...v, status: 'Booked' as 'Booked'} : v);
                saveCollection(KEYS.VEHICLES, updatedVehicles);
            }

            return delay(500, newBooking);
        });
    }
  },

  finance: {
    getInvoices: async (): Promise<Invoice[]> => {
        return safeFetch('/finance/invoices', undefined, async () => {
            return delay(400, getCollection<Invoice>(KEYS.INVOICES, MOCK_INVOICES));
        });
    },
    createInvoice: async (invoice: Omit<Invoice, 'id'>): Promise<Invoice> => {
        return safeFetch('/finance/invoices', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(invoice)
        }, async () => {
            const invoices = getCollection<Invoice>(KEYS.INVOICES, MOCK_INVOICES);
            const newInvoice: Invoice = { ...invoice, id: `inv${Date.now()}` };
            invoices.push(newInvoice);
            saveCollection(KEYS.INVOICES, invoices);
            return delay(500, newInvoice);
        });
    },
    updateInvoice: async (id: string, updates: Partial<Invoice>): Promise<void> => {
        return safeFetch(`/finance/invoices/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updates)
        }, async () => {
            const invoices = getCollection<Invoice>(KEYS.INVOICES, MOCK_INVOICES);
            const updated = invoices.map(i => i.id === id ? { ...i, ...updates } : i);
            saveCollection(KEYS.INVOICES, updated);
            return delay(300, undefined as void);
        });
    },
    // New Finance Features
    getLoans: async (): Promise<LoanApplication[]> => {
        return safeFetch('/finance/loans', undefined, async () => {
            return delay(300, getCollection<LoanApplication>(KEYS.LOANS, []));
        });
    },
    createLoan: async (loan: Omit<LoanApplication, 'id'>): Promise<LoanApplication> => {
        return safeFetch('/finance/loans', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(loan)
        }, async () => {
            const loans = getCollection<LoanApplication>(KEYS.LOANS, []);
            const newLoan = { ...loan, id: `ln${Date.now()}` };
            loans.push(newLoan);
            saveCollection(KEYS.LOANS, loans);
            return delay(400, newLoan);
        });
    },
    updateLoanStatus: async (id: string, status: LoanApplication['status']): Promise<void> => {
        return safeFetch(`/finance/loans/${id}`, {
             method: 'PATCH',
             headers: { 'Content-Type': 'application/json' },
             body: JSON.stringify({ status })
        }, async () => {
             const loans = getCollection<LoanApplication>(KEYS.LOANS, []);
             const updated = loans.map(l => l.id === id ? { ...l, status } : l);
             saveCollection(KEYS.LOANS, updated);
             return delay(200, undefined as void);
        });
    }
  },

  hr: {
    getEmployees: async (): Promise<Employee[]> => {
        return safeFetch('/hr/employees', undefined, async () => {
            return delay(400, getCollection<Employee>(KEYS.EMPLOYEES, MOCK_EMPLOYEES));
        });
    },
    createEmployee: async (employee: Omit<Employee, 'id'>): Promise<Employee> => {
        return safeFetch('/hr/employees', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(employee)
        }, async () => {
            const employees = getCollection<Employee>(KEYS.EMPLOYEES, MOCK_EMPLOYEES);
            const newEmployee: Employee = { ...employee, id: `e${Date.now()}` };
            employees.push(newEmployee);
            saveCollection(KEYS.EMPLOYEES, employees);
            return delay(500, newEmployee);
        });
    },
    addPerformanceReview: async (employeeId: string, review: Omit<PerformanceReview, 'id'>): Promise<void> => {
        return safeFetch(`/hr/employees/${employeeId}/reviews`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(review)
        }, async () => {
            const employees = getCollection<Employee>(KEYS.EMPLOYEES, MOCK_EMPLOYEES);
            const empIndex = employees.findIndex(e => e.id === employeeId);
            
            if (empIndex > -1) {
                const newReview = { ...review, id: `r${Date.now()}` };
                if (!employees[empIndex].reviews) employees[empIndex].reviews = [];
                
                employees[empIndex].reviews.push(newReview);
                
                // Recalculate average
                const total = employees[empIndex].reviews.reduce((sum, r) => sum + r.rating, 0);
                employees[empIndex].performanceRating = Number((total / employees[empIndex].reviews.length).toFixed(1));
                
                saveCollection(KEYS.EMPLOYEES, employees);
                return delay(400, undefined as void);
            }
        });
    }
  },

  services: {
      getJobs: async (): Promise<ServiceJob[]> => {
          return safeFetch('/services/jobs', undefined, async () => {
              return delay(400, getCollection<ServiceJob>(KEYS.SERVICE_JOBS, MOCK_SERVICE_JOBS));
          });
      },
      updateJobStatus: async (id: string, status: ServiceJob['status']): Promise<void> => {
          return safeFetch(`/services/jobs/${id}`, {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ status })
          }, async () => {
              const jobs = getCollection<ServiceJob>(KEYS.SERVICE_JOBS, MOCK_SERVICE_JOBS);
              const updated = jobs.map(j => j.id === id ? { ...j, status } : j);
              saveCollection(KEYS.SERVICE_JOBS, updated);
              return delay(300, undefined as void);
          });
      }
  }
};
