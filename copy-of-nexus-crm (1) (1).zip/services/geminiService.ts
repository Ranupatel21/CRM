
import { GoogleGenAI } from "@google/genai";
import { AppState, Invoice } from "../types";

const getClient = () => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) return null;
    return new GoogleGenAI({ apiKey });
}

export const generateCRMAnalysis = async (prompt: string, contextData: any): Promise<string> => {
  const ai = getClient();
  if (!ai) return "API Key not configured. Please check your environment.";

  try {
    // Serialize context data safely
    const dataStr = JSON.stringify(contextData, null, 2);
    
    const fullPrompt = `
      You are an expert CRM Business Analyst for a company named Nexus.
      Analyze the following JSON data provided from our system and answer the user's prompt.
      Keep the answer professional, concise, and actionable. Use formatting like bolding for key metrics.
      
      Note: All monetary values are in Indian Rupees (INR).

      Data Context:
      ${dataStr}

      User Prompt:
      ${prompt}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: fullPrompt,
    });

    return response.text || "No analysis could be generated.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Sorry, I encountered an error while analyzing the data.";
  }
};

export const draftEmail = async (toName: string, topic: string, tone: string = "Professional"): Promise<string> => {
    const ai = getClient();
    if (!ai) return "API Key missing.";

    try {
        const prompt = `Draft a ${tone} email to ${toName} regarding: ${topic}. Keep it under 200 words.`;
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt
        });
        return response.text || "Could not generate email.";
    } catch (e) {
        console.error(e);
        return "Error generating email.";
    }
}

export const generatePaymentReminder = async (invoice: Invoice): Promise<string> => {
    const ai = getClient();
    if (!ai) return "Could not generate reminder. Check API Key.";

    try {
        const prompt = `
            Write a professional but firm payment reminder email for an invoice.
            Client: ${invoice.clientName}
            Amount Due: ₹${invoice.amount.toLocaleString()}
            Invoice Date: ${invoice.date}
            Invoice ID: ${invoice.id}
            Status: ${invoice.status}

            If the status is 'Overdue', be more urgent. If 'Pending', be polite and a gentle reminder.
            Keep it concise (under 150 words).
            Subject Line: Included at the top.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt
        });

        return response.text || "Email generation failed.";
    } catch (e) {
        return "Error generating reminder.";
    }
}
