
export enum Role {
  MD = 'MD', // Managing Director (Super Admin)
  MANAGER = 'MANAGER',
  EMPLOYEE = 'EMPLOYEE'
}

export enum Department {
  EXECUTIVE = 'EXECUTIVE',
  SALES = 'SALES',
  FINANCE = 'FINANCE',
  HR = 'HR',
  SERVICES = 'SERVICES'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  department: Department;
  avatar: string;
}

export interface Lead {
  id: string;
  customerName: string;
  company: string;
  value: number;
  status: 'New' | 'Contacted' | 'Proposal' | 'Won' | 'Lost';
  assignedToId: string; // User ID
  lastActivity: string;
  nextFollowUp?: string; // YYYY-MM-DD
}

export interface Invoice {
  id: string;
  clientName: string;
  amount: number;
  date: string; // Issue Date
  dueDate?: string; // YYYY-MM-DD
  status: 'Paid' | 'Pending' | 'Overdue';
  departmentId: Department;
  lastReminderSent?: string; // ISO Date string
}

export interface PerformanceReview {
  id: string;
  date: string;
  rating: number; // 1-5
  notes: string;
  goals: string;
  reviewerId: string;
}

export interface Employee {
  id: string;
  name: string;
  position: string;
  department: Department;
  salary: number;
  joinDate: string;
  performanceRating: number; // Current Average
  reviews: PerformanceReview[];
  nextReviewDate?: string; // YYYY-MM-DD
}

export interface Ticket {
  id: string;
  subject: string;
  customerName: string;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Open' | 'In Progress' | 'Resolved';
  assignedToId: string;
}

// --- NEW DEALERSHIP TYPES ---

export interface Vehicle {
  id: string;
  vin: string; // Chassis Number
  model: string; // e.g., Fortuner
  fuelType: 'Petrol' | 'Diesel' | 'Hybrid' | 'Electric';
  variant: string; // e.g., Legender 4x4
  color: string;
  price: number;
  status: 'Available' | 'Booked' | 'Sold';
  image?: string;
}

export interface ServiceJob {
  id: string;
  customerName: string;
  vehicleModel: string;
  registrationNumber: string; // e.g. DL-10-CB-1234
  serviceType: 'General Service' | 'Repair' | 'Washing' | 'Inspection';
  status: 'Pending' | 'In Progress' | 'Washing' | 'Ready' | 'Delivered';
  assignedMechanic?: string;
  estimatedCost: number;
  dateIn: string;
}

export interface TestDrive {
  id: string;
  customerName: string;
  vehicleModel: string;
  date: string; // YYYY-MM-DD
  timeSlot: string; // e.g., "10:00 AM"
  status: 'Scheduled' | 'Completed' | 'Cancelled';
  assignedSalesPersonId: string;
}

export interface Quotation {
  id: string;
  customerName: string;
  vehicleId: string; // Linked to inventory
  exShowroomPrice: number;
  insurance: number;
  registrationCharges: number;
  accessories: number;
  totalOnRoadPrice: number;
  date: string;
}

export interface LoanApplication {
  id: string;
  customerName: string;
  vehicleModel: string;
  bankName: string;
  loanAmount: number;
  status: 'Applied' | 'Processing' | 'Approved' | 'Rejected' | 'Disbursed';
  applicationDate: string;
}

export interface Booking {
  id: string;
  customerName: string;
  phone: string;
  vehicleId: string;
  vehicleDetails: string;
  basePrice: number;
  discount: number;
  accessoriesList: string;
  accessoriesCost: number;
  finalPrice: number;
  bookingAmountPaid: number;
  date: string;
}

// Mock Database State
export interface AppState {
  currentUser: User | null;
  users: User[];
  leads: Lead[];
  invoices: Invoice[];
  employees: Employee[];
  tickets: Ticket[];
  vehicles: Vehicle[];
  serviceJobs: ServiceJob[];
  testDrives: TestDrive[];
  quotations: Quotation[];
  loans: LoanApplication[];
  bookings: Booking[];
}
